# ISBF-One · 加入我们

加入我们页面：`#86C3F5` 蓝色开场、白色透底格纹人物与白色地面。六块黑色悬浮广告保留原来的招募内容，中央黑色广告牌使用重新排版的 `ISBF-One` 字标，品牌大小写全页统一。复现参考页的低机位行走与滚动运镜，穿入黑色白线纵深隧道，再渐变到深色滚动图片页。图片页按参考截图的大标题、横向影像带和下方超大文字结构制作，没有引入原站产品内容。

## 启动

```sh
npm install
npm run dev
```

默认打开终端显示的本地地址（本次为 `http://127.0.0.1:5173`）。

```sh
npm run build
npm run preview
```

需要关闭命令终端后仍可访问本地预览时，运行 `npm run preview:background`。它会以独立进程启动 `http://127.0.0.1:4173/`，日志在 `.preview-server.log`。电脑重启后需要重新运行该命令。

`dist/` 是可部署的静态文件。主体验不依赖第三方 CDN，字体、Draco 解码器和两套模型都在 `public/` 中。

## 接入 isbf-one.com

- 浮动品牌标识和加入入口：`index.html`。首屏介绍文案、顶部导航栏、左下角版次及 `#journey-caption` 章节文案整块已删除。
- 官网链接、正式报名地址、动画起止点与平滑速度：`src/config.js`。
- 蓝底白色人物/地面、黑色隧道、中央广告牌、材质与相机：`src/scene.js`。
- 六块黑底白字悬浮广告（竖版、横版、图形方牌、圆章、票券、立体 ONE），保留 STAY CURIOUS / MAKE IT HAPPEN / CREATE TOGETHER / FIND YOUR PEOPLE / ADMIT ONE 等原内容。左侧图形方牌为星形穿孔，右侧圆牌为两条弧形穿孔，切穿印刷面和挤出背板；圆牌绕垂直地面的 Y 轴随滚动转动，回滚可逆，静止不自转，不是牌面内打转。立体 ONE 与背板按比例留出间隔（含倒角），相机仅在进入隧道时缩小近裁面，改善手机深度闪纹。实现位于 `src/ads.js`、`src/scene.js`。
- 中央广告牌的 `ISBF-One` 字距与排版：`src/brand.js`。
- 顶部、加载页和浏览器图标使用用户提供的透明 PNG：`public/brand/isbf-one-mark.png`。保留原图，开场显示黑色，深色页面以 CSS 反色显示白色；旧星号及圆形 ONE 标识不再显示。
- 隧道后滚动图片带：`src/gallery.js`，图片与标题在 `src/config.js` 的 `gallery.items` 配置。
- 布局、黑底和 `#86C3F5` 点缀：`src/styles.css`，悬停色为 `#A9D6F8`。
- 隧道末段向深色图片页的滚动渐变：`src/main.js` 的 `updateOverlay()`。
- 加入按钮为圆角胶囊，打开深色招募弹窗。简历投递邮箱为 `hr@isbf-one.com`；登记表按姓名、学号、手机联系方式顺序填写。配置在 `src/config.js` 的 `recruitment`。
- 若部署到子目录，例如 `/join/`，使用 `npm run build -- --base=/join/`，把 `dist/` 放到对应目录。
- 集成进现有框架时保留 `.journey`、`.stage`、`#scene` 与滚动进度逻辑，组件卸载时调用场景 `dispose()`。

## 动画与降级

滚动进度驱动模型的同一条时间轴，骨骼步态与相机轨迹同步。六块侧边广告开场隐藏，随行走按近、中、远分批从下方升入，两侧略微错峰；使用真实三维位移，回滚时反向退回下方。人物保留原模型的格纹贴图及 UV，白色线条和面片保留，蓝色区域映射为当前背景色，在保留深度遮挡的同时呈现透背景的视觉效果。末段单独分配穿入隧道的滚动距离，进度 96.5%—100% 淡出到深色图片页。前后滚动均可，点击「重新出发」回到起点，手动滚动会中止自动滚动。鼠标具有轻微视差，手机关闭视差并加载单独的移动模型。场景静止和离开视口时不持续渲染。

中央广告牌仅叠加透明底的 ISBF-One 文字，不使用不透明黑底贴片遮挡入口。白色纵深条纹从广告牌阶段便来自实际隧道的原始几何与 UV，镜头穿入后连续推进；没有按滚动阈值突然显示另一套条纹。

系统启用减少动态效果时，页面改为静态关键帧。WebGL 或模型加载失败时保留品牌标识和加入入口。弹窗支持 Escape、焦点管理和键盘操作。

## 手机全屏与边缘配色

开场使用 `100dvh` 动态视口高度（保留 `100svh` 回退），画布跟随容器尺寸变化，滚动时间轴按实际舞台高度计算。启用 `viewport-fit=cover`，标识、提示和页脚避让安全区。进入图片页后，`html`、`body` 背景与浏览器 `theme-color` 一同改为 `#171717`，穿入隧道时使用 `#050505`，返回开头则恢复蓝色；直接打开 `#join` 也会更新。

按钮箭头、滚动箭头、重播、关闭及成功提示均使用 SVG，不依赖系统 emoji 字体。图库标题向上滚出时，透明品牌标识随介绍区离开，避免覆盖后续正文。

已检查 Chromium 的 390×844、390×664 手机尺寸与 1440×900 桌面布局。浏览器地址栏属于 Safari 系统界面，网页不会强制隐藏；动态工具栏及安全区的最终表现仍需实机 iOS Safari 复查。实现参考 [WebKit 的安全区说明](https://webkit.org/blog/7929/designing-websites-for-iphone-x/) 和 [Apple 的动态视口说明](https://developer.apple.com/videos/play/wwdc2022/10048/)。

## 添加滚动图片

图片页预览：`http://127.0.0.1:4173/#join`。

图片由你添加，目前六个位置均为明确标注的占位框，不会请求不存在的图片。把图片放到 `public/gallery/`，然后编辑 `src/config.js`：

```js
gallery: {
  speed: 28, // 自动滚动速度，像素/秒；设为 0 关闭自动滚动
  items: [
    { image: 'gallery/01.webp', title: '团队日常', alt: '这张图片的内容说明' },
    { image: 'gallery/02.jpg', title: '一起创造', alt: '这张图片的内容说明' },
  ],
},
```

推荐约 1.9:1 的横图，宽 1200—1600px；可以增加或减少条目。留空显示占位，地址失效显示提示，不会留下破图。保存后执行 `npm run build` 并刷新预览。子目录部署时路径自动跟随构建的 `base`。

图片带支持自动无缝循环、页面纵向滚动联动和触控/触控板/键盘横向滚动。图片不显示标题、编号角标或说明条，暂停按钮及页脚英文标语已移除。鼠标悬停、键盘聚焦和触摸操作时暂停自动移动；离开视口或打开弹窗时不持续运行。系统减少动态效果模式关闭自动移动，仅保留手动浏览。

## 招募登记与部署

`npm run preview` / `npm run preview:background` 现在启动同源 Node 服务，同时提供静态页面及 `POST /api/applications`，不再只是 Vite 静态预览。`npm test` 验证校验、保存、幂等、访问边界、限流和保存失败。后端不依赖第三方服务或新增 npm 包。

提交通过客户端、服务端双重校验，数据落盘完成后才显示「感谢您的投递，我们会尽快联系您」。失败显示重试提示，不会伪造成功。重复请求使用提交标识去重。

- 简历仍由申请人邮件投递至 `hr@isbf-one.com`；表单收集联系信息，不自动发送邮件，也不上传简历。
- 登记数据保存在运行服务器的 `.private/applications/`，每条记录一个 JSON 文件。目录及文件权限分别为 0700 / 0600，不进入 Git、`dist/` 或交付压缩包，也没有公开读取接口。
- 开发时同时运行 `npm run dev:api` 和 `npm run dev`，Vite 把 `/api` 转发到 4174。
- 生产部署需要 Node.js 20+，把 `server/`、`shared/` 和构建后的 `dist/` 一起部署，运行 `node server/index.mjs`。默认监听本机 4173；公开网站应通过 HTTPS 反向代理访问。
- 环境变量：`ISBF_HOST`、`ISBF_PORT`、`ISBF_DATA_DIR`。数据目录必须在公开静态目录之外；需要自行维护服务器持久磁盘与私有备份。
- 只上传 `dist/` 的纯静态托管不会自动获得提交能力；此时必须另行部署同源接口，不能仅配置邮箱来代替保存接口。
- 当前接通的是本地预览服务，没有自动部署或修改 `isbf-one.com`。

## 参考与资源来源

参考：https://razorpay.com/sprint/26

本次使用 REA 的浏览器场景录制，结合页面实际发布的脚本与 GLB 结构分析动画。人物、骨骼动画与相机来自参考页公开提供的模型，经过裁剪；支付产品、原招牌文字及其他品牌元素已从可见场景移除，招募广告牌是代码生成的新内容。模型并非新创作。原始资源来源、SHA-256 与优化后尺寸见 `public/models/provenance.json`；正式商用前需要确认参考模型的使用授权，或替换成自有模型。

Inter 字体遵循 SIL Open Font License，授权文件位于 `public/fonts/OFL.txt`。Three.js 与 Draco 解码器的授权文件随源码保留。

`evidence/` 保存 REA 录制场景、关键帧和验证摘要，`evidence/implementation.md` 记录观察结论与实现选择。

可通过以下命令从原始 GLB 重新生成裁剪版本，不需要重新编码 Draco：

```sh
node scripts/prepare-models.mjs /absolute/path/Sprint.glb /absolute/path/Sprint_mobile.glb
```

## Skill

用户指定的 REA skill 已安装到 `/Users/liu./.codex/skills/reverse-engineer-anything`。后续回合可自动发现；本次已经直接读取并使用其指导和 REA 6.4.0 CLI。没有修改 Codex 的 MCP 配置，也没有安装反汇编工具。
