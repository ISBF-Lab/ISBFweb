import { createServer } from 'node:http';
import { createReadStream } from 'node:fs';
import { mkdir, open, readFile, link, unlink, realpath, stat } from 'node:fs/promises';
import { randomUUID } from 'node:crypto';
import { resolve, join, extname, sep } from 'node:path';
import { validateApplication } from '../shared/application.js';

const uuid = /^[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i;
const mime = { '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.css': 'text/css; charset=utf-8', '.json': 'application/json; charset=utf-8', '.svg': 'image/svg+xml', '.png': 'image/png', '.jpg': 'image/jpeg', '.jpeg': 'image/jpeg', '.webp': 'image/webp', '.woff2': 'font/woff2', '.wasm': 'application/wasm', '.glb': 'model/gltf-binary', '.md': 'text/plain; charset=utf-8' };

export async function createApplicationServer({ distDirectory, dataDirectory, rateLimitMax = 20, rateLimitWindowMs = 600000 } = {}) {
  const dist = resolve(distDirectory);
  const data = resolve(dataDirectory);
  if (data === dist || data.startsWith(dist + sep)) throw new Error('Application data must be outside the public directory.');
  await mkdir(data, { recursive: true, mode: 0o700 });
  const limits = new Map();
  const reply = (response, status, body, headers = {}) => {
    response.writeHead(status, { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store', ...headers });
    response.end(JSON.stringify(body));
  };
  const save = async (submissionId, fields) => {
    const destination = join(data, `${submissionId}.json`);
    const pending = join(data, `.pending-${randomUUID()}`);
    const record = { id: submissionId, createdAt: new Date().toISOString(), ...fields };
    let handle;
    try {
      handle = await open(pending, 'wx', 0o600);
      await handle.writeFile(`${JSON.stringify(record)}\n`, 'utf8');
      await handle.sync();
      await handle.close();
      handle = null;
      try {
        // Link publishes a completely-written record without overwriting an
        // existing submission, including when requests arrive concurrently.
        await link(pending, destination);
        return false;
      } catch (error) {
        if (error.code !== 'EEXIST') throw error;
        const existing = JSON.parse(await readFile(destination, 'utf8'));
        if (Object.keys(fields).some((key) => existing[key] !== fields[key])) {
          const conflict = new Error('Submission ID conflict.');
          conflict.status = 409;
          throw conflict;
        }
        return true;
      }
    } finally {
      await handle?.close().catch(() => {});
      await unlink(pending).catch(() => {});
    }
  };

  const server = createServer(async (request, response) => {
    response.setHeader('X-Content-Type-Options', 'nosniff');
    response.setHeader('Referrer-Policy', 'strict-origin-when-cross-origin');
    response.setHeader('X-Frame-Options', 'DENY');
    try {
      const url = new URL(request.url, 'http://localhost');
      if (url.pathname === '/api/health' && request.method === 'GET') {
        return reply(response, 200, { ok: true, applicationService: 'ready' });
      }
      if (url.pathname === '/api/applications') {
        if (request.method !== 'POST') return reply(response, 405, { ok: false, message: '此接口仅接受提交。' }, { Allow: 'POST' });
        const origin = request.headers.origin;
        if ((origin && new URL(origin).host !== request.headers.host) || request.headers['sec-fetch-site'] === 'cross-site') return reply(response, 403, { ok: false, message: '不允许跨站提交。' });
        if (!/^application\/json(?:\s*;|$)/i.test(request.headers['content-type'] || '')) return reply(response, 415, { ok: false, message: '请使用 JSON 提交。' });
        if (Number(request.headers['content-length']) > 4096) {
          request.resume();
          return reply(response, 413, { ok: false, message: '提交内容过长。' });
        }
        const chunks = [];
        let size = 0;
        for await (const chunk of request) {
          size += chunk.length;
          if (size > 4096) return reply(response, 413, { ok: false, message: '提交内容过长。' });
          chunks.push(chunk);
        }
        let input;
        try { input = JSON.parse(Buffer.concat(chunks).toString('utf8')); }
        catch { return reply(response, 400, { ok: false, message: '提交内容格式无效。' }); }
        const result = validateApplication(input);
        if (!result.valid) return reply(response, 400, { ok: false, errors: result.errors, message: '请检查填写的信息。' });
        if (!uuid.test(input.submissionId || '')) return reply(response, 400, { ok: false, message: '提交标识无效，请重新打开表单。' });
        const now = Date.now();
        for (const [key, value] of limits) if (now >= value.until) limits.delete(key);
        const ip = request.socket.remoteAddress;
        const limit = limits.get(ip) || { count: 0, until: now + rateLimitWindowMs };
        if (limit.count >= rateLimitMax) return reply(response, 429, { ok: false, message: '提交过于频繁，请稍后重试。' }, { 'Retry-After': String(Math.ceil((limit.until - now) / 1000)) });
        limit.count += 1;
        limits.set(ip, limit);
        const duplicate = await save(input.submissionId, result.fields);
        return reply(response, duplicate ? 200 : 201, { ok: true, id: input.submissionId });
      }
      if (url.pathname.startsWith('/api/')) return reply(response, 404, { ok: false });
      if (!['GET', 'HEAD'].includes(request.method)) return reply(response, 405, { ok: false });
      let pathname;
      try { pathname = decodeURIComponent(url.pathname); } catch { return reply(response, 400, { ok: false }); }
      if (pathname.split('/').some((part) => part.startsWith('.'))) return reply(response, 404, { ok: false });
      const candidate = resolve(dist, `.${pathname === '/' ? '/index.html' : pathname}`);
      if (!candidate.startsWith(dist + sep)) return reply(response, 404, { ok: false });
      let target; let metadata;
      try {
        target = await realpath(candidate);
        const realDist = await realpath(dist);
        if (!target.startsWith(realDist + sep)) return reply(response, 404, { ok: false });
        metadata = await stat(target);
        if (!metadata.isFile()) return reply(response, 404, { ok: false });
      } catch { return reply(response, 404, { ok: false }); }
      response.writeHead(200, {
        'Content-Type': mime[extname(target)] || 'application/octet-stream',
        'Content-Length': metadata.size,
        'Cache-Control': pathname.startsWith('/assets/') ? 'public, max-age=31536000, immutable' : 'no-cache',
      });
      if (request.method === 'HEAD') response.end();
      else createReadStream(target).on('error', () => response.destroy()).pipe(response);
    } catch (error) {
      if (!response.headersSent) reply(response, error.status === 409 ? 409 : 503, {
        ok: false,
        message: error.status === 409 ? '提交标识已被使用，请重新打开表单。' : '暂时无法保存登记信息，请稍后重试。',
      });
      else response.destroy();
    }
  });
  server.requestTimeout = 15000;
  server.headersTimeout = 10000;
  return server;
}
