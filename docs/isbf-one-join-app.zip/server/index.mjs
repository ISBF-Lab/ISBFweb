import { fileURLToPath } from 'node:url';
import { resolve } from 'node:path';
import { createApplicationServer } from './app.mjs';

const project = fileURLToPath(new URL('../', import.meta.url));
const host = process.env.ISBF_HOST || '127.0.0.1';
const port = Number(process.env.ISBF_PORT || 4173);
const server = await createApplicationServer({
  distDirectory: resolve(project, 'dist'),
  dataDirectory: process.env.ISBF_DATA_DIR || resolve(project, '.private/applications'),
});
server.listen(port, host, () => console.log(`ISBF-One 已启动：http://${host}:${port}/（同源登记接口已启用）`));
process.on('SIGTERM', () => server.close(() => process.exit(0)));
process.on('SIGINT', () => server.close(() => process.exit(0)));
