import test from 'node:test';
import assert from 'node:assert/strict';
import { mkdtemp, mkdir, writeFile, readFile, readdir, rm, stat } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { randomUUID } from 'node:crypto';
import { createApplicationServer } from '../server/app.mjs';
import { validateApplication } from '../shared/application.js';

const example = () => ({ name: ' 测试申请人 ', studentId: ' TEST-2026001 ', phone: '13800000000', submissionId: randomUUID() });
async function fixture(t, options = {}) {
  const directory = await mkdtemp(join(tmpdir(), 'isbf-application-test-'));
  const dist = join(directory, 'dist');
  const data = join(directory, 'private');
  await mkdir(dist);
  await writeFile(join(dist, 'index.html'), '<!doctype html><title>Test</title>');
  const server = await createApplicationServer({ distDirectory: dist, dataDirectory: data, ...options });
  await new Promise((done) => server.listen(0, '127.0.0.1', done));
  t.after(async () => { await new Promise((done) => server.close(done)); await rm(directory, { recursive: true, force: true }); });
  const origin = `http://127.0.0.1:${server.address().port}`;
  const post = (body, headers = {}) => fetch(`${origin}/api/applications`, { method: 'POST', headers: { 'Content-Type': 'application/json', Origin: origin, ...headers }, body: JSON.stringify(body) });
  return { origin, post, data };
}

test('requires name, student ID and a plausible phone in the requested order', () => {
  assert.deepEqual(Object.keys(validateApplication({}).errors), ['name', 'studentId', 'phone']);
  assert.equal(validateApplication({ name: '测试', studentId: 'ABC-123', phone: '+86 13800000000' }).valid, true);
  assert.equal(validateApplication({ ...example(), phone: 'bad-number' }).valid, false);
  assert.equal(validateApplication({ ...example(), name: 'test\nname' }).valid, false);
});

test('acknowledges success only after a private durable record exists; retry is idempotent', async (t) => {
  const { post, data } = await fixture(t);
  const input = example();
  const response = await post(input);
  assert.equal(response.status, 201);
  assert.equal((await response.json()).ok, true);
  const file = join(data, `${input.submissionId}.json`);
  const saved = JSON.parse(await readFile(file, 'utf8'));
  assert.equal(saved.name, '测试申请人');
  assert.equal(saved.studentId, 'TEST-2026001');
  assert.equal(saved.phone, input.phone);
  assert.ok(saved.createdAt);
  if (process.platform !== 'win32') assert.equal((await stat(file)).mode & 0o777, 0o600);
  assert.equal((await post(input)).status, 200);
  assert.equal((await readdir(data)).length, 1);
  assert.equal((await post({ ...input, name: '另一个测试申请人' })).status, 409);
});

test('rejects missing fields, cross-origin requests, oversized bodies, and public reads', async (t) => {
  const { origin, post, data } = await fixture(t);
  assert.equal((await post({})).status, 400);
  assert.equal((await post(example(), { Origin: 'https://unrelated.example' })).status, 403);
  assert.equal((await post({ ...example(), extra: 'x'.repeat(5000) })).status, 413);
  assert.equal((await fetch(`${origin}/api/applications`)).status, 405);
  assert.equal((await fetch(`${origin}/.private/applications.json`)).status, 404);
  assert.deepEqual(await readdir(data), []);
});

test('rate limits repeated submissions without accepting another record', async (t) => {
  const { post, data } = await fixture(t, { rateLimitMax: 1 });
  assert.equal((await post(example())).status, 201);
  assert.equal((await post(example())).status, 429);
  assert.equal((await readdir(data)).length, 1);
});

test('returns failure rather than false success when persistence fails', async (t) => {
  const { post, data } = await fixture(t);
  await rm(data, { recursive: true });
  const response = await post(example());
  assert.equal(response.status, 503);
  assert.equal((await response.json()).ok, false);
});
