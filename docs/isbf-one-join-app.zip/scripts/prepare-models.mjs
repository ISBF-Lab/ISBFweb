// Prune the supplied reference GLBs without decoding/re-encoding Draco geometry.
// Only the authored walk, camera, rails and central billboard are retained.
import { readFile, writeFile } from 'node:fs/promises';
import { createHash } from 'node:crypto';
import { resolve } from 'node:path';

const [desktopInput, mobileInput] = process.argv.slice(2);
if (!desktopInput || !mobileInput) throw new Error('Provide the original desktop and mobile GLBs.');
const roots = new Set(['SpeedLines.001', 'Railing_R.001', 'Railing_L.001', 'Railing.001', 'MainSkeleton.001', 'Ground.001', 'BillboardInt.001', 'BillboardInt.002', 'BillboardInt.003']);
const manifest = [];
for (const [input, platform, url] of [
  [desktopInput, 'desktop', 'https://pub-6903216751f64c07b3cecf6009faf318.r2.dev/Sprint.glb'],
  [mobileInput, 'mobile', 'https://pub-6903216751f64c07b3cecf6009faf318.r2.dev/Sprint_mobile.glb'],
]) {
  const source = await readFile(input);
  if (source.readUInt32LE(0) !== 0x46546c67) throw new Error('Expected GLB input');
  const jsonLength = source.readUInt32LE(12);
  const doc = JSON.parse(source.subarray(20, 20 + jsonLength).toString());
  const binary = source.subarray(28 + jsonLength);
  const anchor = doc.nodes.find((node) => node.name === 'Curve.126');
  doc.extras = { ...doc.extras, isbfBillboardAnchor: { translation: anchor.translation, rotation: anchor.rotation, scale: anchor.scale } };
  const sets = Object.fromEntries(['nodes', 'meshes', 'skins', 'materials', 'textures', 'images', 'samplers', 'accessors', 'bufferViews'].map((key) => [key, new Set()]));
  const add = (kind, value) => { if (Number.isInteger(value)) sets[kind].add(value); };
  const visit = (index) => {
    if (sets.nodes.has(index)) return;
    sets.nodes.add(index);
    const node = doc.nodes[index];
    add('meshes', node.mesh); add('skins', node.skin);
    node.children?.forEach(visit);
  };
  doc.scenes.forEach((scene) => { scene.nodes = scene.nodes.filter((index) => roots.has(doc.nodes[index].name)); scene.nodes.forEach(visit); });
  for (const index of sets.skins) {
    const skin = doc.skins[index];
    skin.joints.forEach(visit);
    if (skin.skeleton !== undefined) visit(skin.skeleton);
    add('accessors', skin.inverseBindMatrices);
  }
  for (const index of sets.meshes) for (const primitive of doc.meshes[index].primitives) {
    add('materials', primitive.material);
    Object.values(primitive.attributes).forEach((value) => add('accessors', value));
    add('accessors', primitive.indices);
    primitive.targets?.forEach((target) => Object.values(target).forEach((value) => add('accessors', value)));
    add('bufferViews', primitive.extensions?.KHR_draco_mesh_compression?.bufferView);
  }
  doc.animations = doc.animations.map((animation) => {
    const channels = animation.channels.filter((channel) => sets.nodes.has(channel.target.node));
    const used = [...new Set(channels.map((channel) => channel.sampler))].sort((a, b) => a - b);
    const mapping = new Map(used.map((value, index) => [value, index]));
    const samplers = used.map((index) => animation.samplers[index]);
    samplers.forEach((sampler) => { add('accessors', sampler.input); add('accessors', sampler.output); });
    return { ...animation, channels: channels.map((channel) => ({ ...channel, sampler: mapping.get(channel.sampler) })), samplers };
  }).filter((animation) => animation.channels.length);
  const textureInfo = (object, callback) => {
    if (!object || typeof object !== 'object') return;
    for (const [key, value] of Object.entries(object)) {
      if (key.endsWith('Texture') && value && Number.isInteger(value.index)) callback(value);
      else if (value && typeof value === 'object') textureInfo(value, callback);
    }
  };
  for (const index of sets.materials) {
    const material = doc.materials[index];
    // These source textures are replaced by the black floor and neutral tags.
    if (['Ground', 'BlueTag'].includes(material.name)) {
      delete material.emissiveTexture;
      if (material.pbrMetallicRoughness) delete material.pbrMetallicRoughness.baseColorTexture;
    }
    textureInfo(material, (info) => add('textures', info.index));
  }
  for (const index of sets.textures) {
    const texture = doc.textures[index];
    add('images', texture.source); add('samplers', texture.sampler);
    for (const ext of Object.values(texture.extensions || {})) add('images', ext.source);
  }
  for (const index of sets.images) add('bufferViews', doc.images[index].bufferView);
  for (const index of sets.accessors) {
    const accessor = doc.accessors[index];
    add('bufferViews', accessor.bufferView);
    add('bufferViews', accessor.sparse?.indices.bufferView);
    add('bufferViews', accessor.sparse?.values.bufferView);
  }
  const maps = {};
  for (const [key, selected] of Object.entries(sets)) {
    const ordered = [...selected].sort((a, b) => a - b);
    maps[key] = new Map(ordered.map((old, index) => [old, index]));
    doc[key] = ordered.map((index) => doc[key][index]);
  }
  const remap = (kind, value) => maps[kind].get(value);
  const set = (object, key, kind) => { if (object[key] !== undefined) object[key] = remap(kind, object[key]); };
  doc.scenes.forEach((scene) => { scene.nodes = scene.nodes.map((index) => remap('nodes', index)); });
  for (const node of doc.nodes) {
    if (node.children) node.children = node.children.map((index) => remap('nodes', index));
    set(node, 'mesh', 'meshes'); set(node, 'skin', 'skins');
  }
  for (const skin of doc.skins) {
    skin.joints = skin.joints.map((index) => remap('nodes', index));
    set(skin, 'skeleton', 'nodes'); set(skin, 'inverseBindMatrices', 'accessors');
  }
  for (const animation of doc.animations) {
    for (const channel of animation.channels) channel.target.node = remap('nodes', channel.target.node);
    for (const sampler of animation.samplers) { set(sampler, 'input', 'accessors'); set(sampler, 'output', 'accessors'); }
  }
  for (const mesh of doc.meshes) for (const primitive of mesh.primitives) {
    set(primitive, 'material', 'materials'); set(primitive, 'indices', 'accessors');
    for (const key of Object.keys(primitive.attributes)) primitive.attributes[key] = remap('accessors', primitive.attributes[key]);
    for (const target of primitive.targets || []) for (const key of Object.keys(target)) target[key] = remap('accessors', target[key]);
    const draco = primitive.extensions?.KHR_draco_mesh_compression;
    if (draco) draco.bufferView = remap('bufferViews', draco.bufferView);
  }
  doc.materials.forEach((material) => textureInfo(material, (info) => { info.index = remap('textures', info.index); }));
  for (const texture of doc.textures) {
    set(texture, 'source', 'images'); set(texture, 'sampler', 'samplers');
    for (const ext of Object.values(texture.extensions || {})) set(ext, 'source', 'images');
  }
  doc.images.forEach((image) => set(image, 'bufferView', 'bufferViews'));
  for (const accessor of doc.accessors) {
    set(accessor, 'bufferView', 'bufferViews');
    if (accessor.sparse) { set(accessor.sparse.indices, 'bufferView', 'bufferViews'); set(accessor.sparse.values, 'bufferView', 'bufferViews'); }
  }
  let binaryLength = 0;
  const parts = [];
  for (const view of doc.bufferViews) {
    if ((view.buffer || 0) !== 0) throw new Error('Only single-buffer GLBs are supported');
    const padding = (4 - binaryLength % 4) % 4;
    if (padding) { parts.push(Buffer.alloc(padding)); binaryLength += padding; }
    parts.push(binary.subarray(view.byteOffset || 0, (view.byteOffset || 0) + view.byteLength));
    view.byteOffset = binaryLength;
    view.buffer = 0;
    binaryLength += view.byteLength;
  }
  const binaryPadding = (4 - binaryLength % 4) % 4;
  if (binaryPadding) parts.push(Buffer.alloc(binaryPadding));
  doc.buffers = [{ byteLength: binaryLength }];
  const json = Buffer.from(JSON.stringify(doc));
  const jsonPadding = (4 - json.byteLength % 4) % 4;
  const jsonChunk = Buffer.concat([json, Buffer.alloc(jsonPadding, 0x20)]);
  const binaryChunk = Buffer.concat(parts);
  const header = Buffer.alloc(20);
  header.writeUInt32LE(0x46546c67, 0); header.writeUInt32LE(2, 4);
  header.writeUInt32LE(28 + jsonChunk.length + binaryChunk.length, 8);
  header.writeUInt32LE(jsonChunk.length, 12); header.writeUInt32LE(0x4e4f534a, 16);
  const binaryHeader = Buffer.alloc(8);
  binaryHeader.writeUInt32LE(binaryChunk.length, 0); binaryHeader.writeUInt32LE(0x004e4942, 4);
  const output = Buffer.concat([header, jsonChunk, binaryHeader, binaryChunk]);
  const path = resolve(`public/models/journey-${platform}.glb`);
  await writeFile(path, output);
  manifest.push({ platform, source: url, source_sha256: createHash('sha256').update(source).digest('hex'), output_sha256: createHash('sha256').update(output).digest('hex'), source_bytes: source.length, output_bytes: output.length, nodes: doc.nodes.length, animations: doc.animations.length, images: doc.images.length });
}
await writeFile('public/models/provenance.json', `${JSON.stringify(manifest, null, 2)}\n`);
console.log(JSON.stringify(manifest, null, 2));
