import { readFile, writeFile, mkdir } from 'node:fs/promises';
import { resolve } from 'node:path';

const [input, destination] = process.argv.slice(2);
if (!input || !destination) throw new Error('Usage: node scripts/rea-artifacts.mjs <evidence.json> <destination>');
const evidence = JSON.parse(await readFile(input, 'utf8'));
const capture = evidence.normalized_result || evidence.details?.partial_observation?.capture;
if (!capture?.steps) throw new Error(JSON.stringify({ code: evidence.code, message: evidence.message || evidence.error }));
await mkdir(destination, { recursive: true });
const steps = [];
for (const step of capture.steps) {
  const screenshot = step.artifacts?.screenshot;
  if (screenshot?.state === 'captured') {
    await writeFile(resolve(destination, `${step.step_id}.png`), Buffer.from(screenshot.value.data_base64, 'base64'));
  }
  steps.push({ step: step.step_id, status: step.status, error: step.error });
}
const summary = {
  evidence_id: evidence.evidence_id,
  operation_error: evidence.code || null,
  browser: capture.browser,
  duration_ms: capture.duration_ms,
  steps,
  events: capture.events,
  completeness: capture.completeness,
  limitations: evidence.limitations,
};
await writeFile(resolve(destination, 'summary.json'), `${JSON.stringify(summary, null, 2)}\n`);
console.log(JSON.stringify({
  evidence_id: summary.evidence_id,
  duration_ms: summary.duration_ms,
  steps: summary.steps,
  issues: summary.events.items.filter((event) => event.kind === 'page-error' || event.level === 'error' || event.level === 'warning').slice(0, 12),
  event_count: summary.events.retained,
  completeness: summary.completeness,
}, null, 2));
