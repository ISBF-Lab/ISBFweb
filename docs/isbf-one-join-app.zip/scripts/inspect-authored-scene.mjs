import { readFile } from 'node:fs/promises';
import * as THREE from 'three';

const bytes = await readFile(process.argv[2] || 'public/models/journey-desktop.glb');
const jsonLength = bytes.readUInt32LE(12);
const doc = JSON.parse(bytes.subarray(20, 20 + jsonLength).toString());
const binaryStart = 28 + jsonLength;
const readAccessor = (index) => {
  const accessor = doc.accessors[index];
  const view = doc.bufferViews[accessor.bufferView];
  const length = accessor.count * ({ SCALAR: 1, VEC3: 3, VEC4: 4 }[accessor.type]);
  const offset = binaryStart + (view.byteOffset || 0) + (accessor.byteOffset || 0);
  return Float32Array.from({ length }, (_, i) => bytes.readFloatLE(offset + i * 4));
};
const objects = doc.nodes.map((node) => {
  let object;
  if (node.camera !== undefined) {
    const camera = doc.cameras[node.camera].perspective;
    object = new THREE.PerspectiveCamera(THREE.MathUtils.radToDeg(camera.yfov), 1440 / 900, 0.001, 1000);
  } else object = new THREE.Object3D();
  object.name = THREE.PropertyBinding.sanitizeNodeName(node.name || '');
  if (node.translation) object.position.fromArray(node.translation);
  if (node.rotation) object.quaternion.fromArray(node.rotation);
  if (node.scale) object.scale.fromArray(node.scale);
  return object;
});
doc.nodes.forEach((node, i) => node.children?.forEach((index) => objects[i].add(objects[index])));
const scene = new THREE.Scene();
doc.scenes[0].nodes.forEach((index) => scene.add(objects[index]));
const mixer = new THREE.AnimationMixer(scene);
let duration = 0;
for (const clip of doc.animations) {
  const tracks = clip.channels.filter((channel) => channel.target.path !== 'weights').map((channel) => {
    const sampler = clip.samplers[channel.sampler];
    const name = `${objects[channel.target.node].name}.${({ translation: 'position', rotation: 'quaternion', scale: 'scale' })[channel.target.path]}`;
    const Type = channel.target.path === 'rotation' ? THREE.QuaternionKeyframeTrack : THREE.VectorKeyframeTrack;
    return new Type(name, readAccessor(sampler.input), readAccessor(sampler.output));
  });
  const action = mixer.clipAction(new THREE.AnimationClip(clip.name, -1, tracks));
  action.setLoop(THREE.LoopOnce, 1); action.clampWhenFinished = true; action.play();
  duration = Math.max(duration, action.getClip().duration);
}
const camera = objects.find((object) => object.isCamera);
const portal = objects.find((object) => object.name === 'BillboardInt002');
const round = (vector) => vector.toArray().map((value) => Number(value.toFixed(3)));
const anchors = [[-22.46, -3.39, 19.93], [-21.74, -6.3, 10.62], [-34.17, -16.12, -2.93], [-5, -3.71, 20.86], [-6.05, -6.96, 17.41], [-2.14, -4.79, 9.71]];
for (const progress of [0.02, 0.2, 0.35, 0.5, 0.65, 0.8, 0.9, 0.94, 0.96, 0.97, 0.98, 0.998]) {
  mixer.setTime(Math.min(progress * duration, duration - 0.012));
  scene.updateMatrixWorld(true);
  console.log(JSON.stringify({ progress, camera: round(camera.getWorldPosition(new THREE.Vector3())), cameraScale: round(camera.getWorldScale(new THREE.Vector3())), portalDepth: round(portal.worldToLocal(camera.getWorldPosition(new THREE.Vector3()))), direction: round(camera.getWorldDirection(new THREE.Vector3())), projectedAnchors: anchors.map((point) => round(new THREE.Vector3(...point).project(camera))), board: round(new THREE.Vector3(-11.36, 14.5, 7.4).project(camera)) }));
}
if (process.argv.includes('--props')) {
  mixer.setTime(duration * 0.35);
  scene.updateMatrixWorld(true);
  for (const name of ['vaseCTRL.001', 'checkoutCTRL.001', 'Ray.001', 'Empty', 'darktexture', 'AdSpends.001']) {
    const index = doc.nodes.findIndex((node) => node.name === name);
    const bounds = new THREE.Box3();
    const visit = (i) => {
      const node = doc.nodes[i];
      for (const primitive of doc.meshes[node.mesh]?.primitives || []) {
        const accessor = doc.accessors[primitive.attributes.POSITION];
        if (accessor.min && accessor.max) bounds.union(new THREE.Box3(new THREE.Vector3(...accessor.min), new THREE.Vector3(...accessor.max)).applyMatrix4(objects[i].matrixWorld));
      }
      node.children?.forEach(visit);
    };
    visit(index);
    console.log(JSON.stringify({ prop: name, center: round(bounds.getCenter(new THREE.Vector3())), size: round(bounds.getSize(new THREE.Vector3())), projected: round(bounds.getCenter(new THREE.Vector3()).project(camera)) }));
  }
}
