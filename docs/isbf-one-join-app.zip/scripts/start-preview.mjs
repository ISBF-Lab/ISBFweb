import { spawn } from 'node:child_process';
import { openSync, closeSync, existsSync } from 'node:fs';
import { fileURLToPath } from 'node:url';
import { join } from 'node:path';

const projectDirectory = fileURLToPath(new URL('../', import.meta.url));
const address = 'http://127.0.0.1:4173/';
const isReady = async () => {
  try {
    const response = await fetch(address, { signal: AbortSignal.timeout(700) });
    if (!response.ok || !(await response.text()).includes('加入我们 — ISBF-One')) return false;
    const health = await fetch(`${address}api/health`, { signal: AbortSignal.timeout(700) });
    return health.ok && (await health.json()).applicationService === 'ready';
  } catch { return false; }
};

if (await isReady()) {
  console.log(`预览已在运行：${address}`);
} else {
  if (!existsSync(join(projectDirectory, 'dist/index.html'))) throw new Error('请先运行 npm run build。');
  const logPath = join(projectDirectory, '.preview-server.log');
  const log = openSync(logPath, 'a');
  const child = spawn(process.execPath, [join(projectDirectory, 'server/index.mjs')], {
    cwd: projectDirectory,
    detached: true,
    stdio: ['ignore', log, log],
  });
  child.unref();
  closeSync(log);
  let ready = false;
  for (let attempt = 0; attempt < 35; attempt += 1) {
    if (await isReady()) { ready = true; break; }
    await new Promise((resolve) => setTimeout(resolve, 200));
  }
  if (!ready) throw new Error(`预览未启动，请检查 ${logPath}`);
  console.log(`预览已启动：${address}\n进程：${child.pid}；日志：${logPath}`);
}
