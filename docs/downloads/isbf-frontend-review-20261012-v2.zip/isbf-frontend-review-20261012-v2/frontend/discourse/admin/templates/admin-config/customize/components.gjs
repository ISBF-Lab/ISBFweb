import Components from "discourse/admin/components/admin-config-areas/components";
import DBreadcrumbsItem from "discourse/ui-kit/d-breadcrumbs-item";
import { i18n } from "discourse-i18n";

export default <template>
  <DBreadcrumbsItem
    @label={{i18n "admin.config_areas.themes_and_components.components.title"}}
    @path="/admin/config/customize/components"
  />

  <Components />
</template>
