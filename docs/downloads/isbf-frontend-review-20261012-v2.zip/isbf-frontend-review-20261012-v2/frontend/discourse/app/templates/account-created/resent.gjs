import { trustHTML } from "@ember/template";
import SignupProgressBar from "discourse/components/signup-progress-bar";
import { i18n } from "discourse-i18n";

export default <template>
  <SignupProgressBar @step="activate" />
  <div class="ac-message">
    {{#if @controller.email}}
      {{trustHTML
        (i18n
          "login.sent_activation_email_again" currentEmail=@controller.email
        )
      }}
    {{else}}
      {{i18n "login.sent_activation_email_again_generic"}}
    {{/if}}
  </div>
</template>
