import { trustHTML } from "@ember/template";
import ActivationControls from "discourse/components/activation-controls";
import SignupProgressBar from "discourse/components/signup-progress-bar";
import WelcomeHeader from "discourse/components/welcome-header";

export default <template>
  <SignupProgressBar @step="activate" />
  <WelcomeHeader @header={{@controller.welcomeTitle}} />
  <div class="success-info">
    {{trustHTML @controller.accountCreated.message}}
  </div>
  {{#if @controller.accountCreated.show_controls}}
    <ActivationControls
      @editActivationEmail={{@controller.editActivationEmail}}
      @sendActivationEmail={{@controller.sendActivationEmail}}
    />
  {{/if}}
</template>
