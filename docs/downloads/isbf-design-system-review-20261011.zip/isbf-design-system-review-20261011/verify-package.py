from pathlib import Path
import hashlib

root = Path(__file__).resolve().parent
count = 0
for line in (root / "SHA256SUMS.txt").read_text(encoding="utf-8").splitlines():
    digest, name = line.split("  ", 1)
    path = root / name
    assert path.is_file(), "Missing: " + name
    assert hashlib.sha256(path.read_bytes()).hexdigest() == digest, "Mismatch: " + name
    count += 1
print("PASS:", count, "files verified")
