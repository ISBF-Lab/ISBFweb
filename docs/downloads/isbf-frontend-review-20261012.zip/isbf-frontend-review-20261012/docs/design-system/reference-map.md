# Reference Map：修改页面前选参考

先读 [UI 状态](ui-status.md)、[tokens](tokens.md)、[组件规范](components.md)，再按本表找设计来源。`Axx` 是 UI 状态中的批准区域；`Cxx` 是组件规范中的条目。仅参考明确批准的区域及状态，不用同一路由的其他原生内容补齐设计。

## 执行步骤

1. 定位目标页面的 route、template/component、插件出口、主题 selector 与开关，明确桌面/手机、明暗、权限及状态。
2. 从 `ui-status.md` 选择与用途匹配的 Approved reference；使用 `references/manifest.json` 核对真实源码及版本。工作区不一致时先读验收副本，不能直接把工作区目录当成完整标准。
3. 复用业务组件和已有 tokens；工程控件遵守 UI kit/FormKit/float-kit 公开 API。目标视觉属性逐项写明来源，局部数值只用于原作用域或已确认的相同用途。
4. 若组件、状态或响应式方案没有匹配参考，先提出设计方案，明确可复用部分、缺失规则和需人工确认的决定，获得确认后再实现。不能从 Legacy、历史原型或个人审美补值。
5. 完成后按同一参考比较桌面/手机、明暗及修改涉及的状态，检查原有权限、导航、键盘、动态数据与安全区。只有实际验收覆盖的部分才能申请成为新的 Approved reference。

## 页面映射

| 修改目标                             | Approved Reference / 实际来源                                                                                                                                                                                                                                                                                        | Reuse：可复用内容                                                                     | 边界与缺口                                                                                               |
| ------------------------------------ | -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- | ------------------------------------------------------------------------------------- | -------------------------------------------------------------------------------------------------------- |
| 首页、最新话题、普通 Topic List      | A01/A02；C01/C04/C09；[feed-card](references/theme-4/javascripts/discourse/components/isbf-v2-feed-card.gjs.txt)、[列表出口](references/theme-4/javascripts/discourse/connectors/topic-list-item/isbf-feed-card.gjs.txt)                                                                                             | shell、中央列、作者/正文、分隔线、互动组、手机间距                                    | 定制 feed 与原生 fallback 分开；确认当前 route 的接管条件，不给全部表格新增圆角 Card                     |
| 普通 Topic 详情                      | A04/A01；C01/C03/C09；[topic-card scope](references/theme-4/javascripts/discourse/lib/topic-card-scope.js.txt)、[reading](references/theme-4/javascripts/discourse/components/isbf-topic-reading.gjs.txt)、[topic-reading.scss](references/theme-4/stylesheets/topic-reading.scss.txt)                               | 普通帖子布局、真实菜单动作、阅读导航与已有正文规则                                    | 仅 regular、非嵌套和普通 post；复用 Core 单个阅读导航实例，不复制时间轴；私信和特殊帖另提方案            |
| 官方消息列表、活动摘要               | A03；C01/C06/C11；[official-feed](references/theme-4/javascripts/discourse/components/isbf-official-feed.gjs.txt)、[activity-summary](references/theme-4/javascripts/discourse/components/isbf-official-activity-summary.gjs.txt)、[official-filters.scss](references/theme-4/stylesheets/official-filters.scss.txt) | 消息顺序、筛选、活动字段、双列 grid、缺省翻译、既有互动                               | 依赖官方路径配置；手机仍两列；不创造活动字段或历史关联                                                   |
| 日历、时间项编辑、备注、变更查看     | A07；C07/C08/C11；[calendar](references/theme-4/javascripts/discourse/components/isbf-v2-calendar.gjs.txt)、[calendar-editor](references/theme-4/javascripts/discourse/components/isbf-official-calendar-editor.gjs.txt)、[official-calendar.scss](references/theme-4/stylesheets/official-calendar.scss.txt)        | 现有日历布局、真实编辑器、FormKit 字段、DModal、条目边框/间距                         | 日期及通知语义保留；生产验证未写入真实帖子，不推断全部成功/错误视觉状态；无通用 modal 尺寸标准           |
| 当前用户分组通知                     | A05；C05/C06/C13；[notifications](references/theme-4/javascripts/discourse/components/isbf-notifications.gjs.txt)、[action](references/theme-4/javascripts/discourse/components/isbf-notification-action.gjs.txt)                                                                                                    | heading、tabs、分组/条目、独立折叠及已验证的重试/分页/键盘                            | 检查当前用户及 `isbf_notifications_enabled`；不要增加整个 topic 折叠或改用公开活动预览                   |
| 探索分类                             | A06/A02；C06/C09；[explore](references/theme-4/javascripts/discourse/components/isbf-explore.gjs.txt)、[group](references/theme-4/javascripts/discourse/components/isbf-explore-group.gjs.txt)                                                                                                                       | 已接入分类分组结构、主题卡片与颜色变量                                                | 仅 `/categories` 且开关启用；全部 picker/错误/空态视觉未获确认；搜索和标签内层另处理                     |
| 工作台入口                           | A08/A01；C02/C04；[workbench](references/theme-4/javascripts/discourse/components/isbf-v2-workbench.gjs.txt)                                                                                                                                                                                                         | 既有入口网格、图标局部颜色、卡片尺寸、4/3/4 列覆盖                                    | 入口占位不等于功能已实现；不把工作台卡片外观推广到信息流                                                 |
| 商品列表                             | A09；C02；[marketplace-card](references/theme-4/javascripts/discourse/components/isbf-marketplace-card.gjs.txt)、[marketplace.scss](references/theme-4/stylesheets/marketplace.scss.txt)                                                                                                                             | 商品行、缩略图、价格、分隔线、hover/focus、移动尺寸                                   | 必须等待实际商品渲染；发布、上传和全部错误态缺少完整规范                                                 |
| 校友目录、地图展示                   | A10；[alumni](references/theme-4/javascripts/discourse/components/isbf-alumni.gjs.txt)、[alumni-map](references/theme-4/javascripts/discourse/components/isbf-alumni-map.gjs.txt)、common `.isbf-alumni`                                                                                                             | 已有地图区域尺寸、目录 grid、header、手机单列                                         | 验收明确地图初始化；编辑弹窗、所有筛选/无数据状态需确认；不当作通用用户卡                                |
| 公开个人资料顶部                     | A11/A14；C03/C10；common profile 区域、头像框附件                                                                                                                                                                                                                                                                    | 封面/无封面规则、头像边框与装饰层、顶部内容间距                                       | 上传封面与无封面、展开与收起分别看完整级联；不涵盖 preferences 与 user-card                              |
| 后台头像框校准区 | A15/A14；C14/C03；[确认方案](proposals/avatar-frame-calibration-20261011.md)、2026-10-11 头像框参考附件 | 144px/48px 叠加预览、单列数字输入、确认；保留原上传字段与 FormKit 行为 | 仅新建/编辑上传字段内；不批准后台导航、表格或通用表单；现有两款由用户自行调整 |
| 公开用户活动、右栏最近讨论           | A12；C12；[activity-preview](references/theme-4/javascripts/discourse/components/isbf-activity-preview.gjs.txt)、[post-preview](references/theme-4/javascripts/discourse/components/isbf-post-preview.gjs.txt)                                                                                                       | 摘要、缩略图、原生作者/分类/时间、既有加载与失败回退                                  | 公开活动最多 3 图；右栏无标题时两行/1 图；草稿、书签、待审核、私信、通知被明确排除                       |
| 登录、邀请码注册                     | A13；C01/C08；[已验收认证组件](references/plugins/discourse-academy-roles/accepted-20261011/assets/javascripts/discourse/components/academy-auth-page.gjs.txt)、[已验收认证样式](references/plugins/discourse-academy-roles/accepted-20261011/assets/stylesheets/common/academy-auth.scss.txt)                       | 原生登录/验证码流程、品牌设置、面板、居中输入、密码显隐、主题菜单、触控与减弱动效处理 | 认证专用字体/粒子/半径不移植到论坛；不要使用历史暂停版本或原型包覆盖当前参考                             |
| 用户偏好设置表单                     | 可参考 A01 外层与 A11 顶部中实际保留的区域；工程能力 C08 / FormKit                                                                                                                                                                                                                                                   | 现有颜色/字体变量、可确认的外层布局、原生表单能力                                     | **没有匹配 Approved 设置表单**；布局、字段、保存/错误状态先提设计方案；不能套认证居中表单                |
| 用户弹出卡                           | A11/C03 只能提供公开资料与头像的局部参考                                                                                                                                                                                                                                                                             | 现有头像组件、语义颜色，以及方案明确复用的局部值                                      | **没有 Approved 通用 User Profile Card**；原生 user-card 是 Legacy；尺寸、字段排列与状态需人工确认       |
| 书签、草稿、待审核、私信             | A01 仅对实际接管外层可用；C09/C12 仅用于比较边界                                                                                                                                                                                                                                                                     | 当前真实数据/权限、已有工程原语和确定的语义 token                                     | **没有完整条目视觉规范**；不得用公开帖子接管规则或预览强制替换                                           |
| 全页搜索、标签目录                   | A01 外层；A06 仅可说明相邻探索结构                                                                                                                                                                                                                                                                                   | 外层列宽、字体/颜色变量；已有搜索/标签行为                                            | **内部仍是 Legacy**；搜索条件、结果、目录与状态先提方案，不能把分类探索整块复制过来                      |
| 举报及其他新弹窗                     | A07/C07 的原语使用方式；已有举报样式只供代码理解                                                                                                                                                                                                                                                                     | DModal、已有行为与明确批准的相同任务结构                                              | 通用宽度/遮罩/内距缺失，举报全部视觉状态未批准；新增任务先确认方案                                       |
| 后台、群组、聊天及未知插件页面       | 没有匹配的完整 Approved reference；头像框校准区例外见 A15/C14                                                                                                                                                                                                                                                                                | 平台的 UI kit/FormKit 及原有业务行为                                                  | 后台/群组当前内层 Legacy；聊天和不可读插件未分类。先确认目标，不从 Foundation/Horizon 或插件默认 UI 推导 |
| 学习资源、匿名帖子、徽章、信息页内部 | A01 仅限既有 shell；内部本次未完成核验                                                                                                                                                                                                                                                                               | 确认的外层/语义 token                                                                 | **需要人工确认**各区域实际完成度；有文件或 CSS 导入不等于批准                                            |

## 三个执行示例

### 重构 Topic List

选择 A01/A02，读取 feed-card、出口和完整 common 样式，确定当前是定制卡片还是原生 fallback。直接复用对应组件、spacing、分隔线、正文和互动规则。若目标要求新增一种“置顶卡片”而源码没有匹配，先说明现有置顶语义、拟复用区域与新增视觉缺口，等待确认；不能临时加边框色或阴影。

### 重构 Preferences

读取 Legacy 设置模板与当前插件字段，保留数据及验证。A01/A11 只能提供实际适用的外层/顶部，FormKit 提供工程能力；没有已批准的设置页表单布局。方案应标明字段分组、标签/输入位置、动作和状态分别复用什么，哪些要人工确认。确认前不实现新的表单外观。

### 重构 User Card

先区分公开资料 hero、校友目录和点击头像弹出卡。前两者的局部 Approved 不能自动覆盖第三者。复用头像 helper 和真实权限/字段，列出弹出卡尺寸、内容顺序、actions 与移动行为的缺口；等待设计确认后再改 Legacy `user-card-contents`。

## 提交方案所需记录

方案至少包含目标区域/状态、Approved ID 与真实路径、拟复用组件/tokens、没有依据的规则及需人工确认的选择。批准的新规则必须先补来源与验收范围，再同步四份文档；不要以“看起来一致”替代可追溯证据。

## 2026-10-12：本轮前台统一

[运行基线](baselines/README.md)、[19组执行记录](frontend-rollout-20261012.md)
及[D01–D07代表提案](proposals/frontend-consistency-20261012.md)已建立。
新用途组合待人工确认，基线附件和离线预览不自动成为Approved；后台排除。
遵照用户要求[控制内存](resource-policy.md)，停止生产排查。
