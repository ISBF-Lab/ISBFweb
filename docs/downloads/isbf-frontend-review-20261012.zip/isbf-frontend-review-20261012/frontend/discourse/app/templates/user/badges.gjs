import { fn } from "@ember/helper";
import PluginOutlet from "discourse/components/plugin-outlet";
import bodyClass from "discourse/helpers/body-class";
import lazyHash from "discourse/helpers/lazy-hash";
import DBadgeCard from "discourse/ui-kit/d-badge-card";
import { i18n } from "discourse-i18n";

export default <template>
  {{bodyClass "user-badges-page"}}

  <section class="user-content" id="user-content">
    <PluginOutlet
      @name="user-badges-content"
      @outletArgs={{lazyHash
        sortedBadges=@controller.sortedBadges
        maxFavBadges=@controller.siteSettings.max_favorite_badges
        favoriteBadges=@controller.favoriteBadges
        canFavoriteMoreBadges=@controller.canFavoriteMoreBadges
        favorite=@controller.favorite
      }}
    >
      {{#if @controller.siteSettings.max_favorite_badges}}
        <p class="favorite-count">
          {{i18n
            "badges.favorite_count"
            count=@controller.favoriteBadges.length
            max=@controller.siteSettings.max_favorite_badges
          }}
        </p>
      {{/if}}

      <div class="badge-group-list">
        {{#each @controller.sortedBadges as |ub|}}
          <DBadgeCard
            @badge={{ub.badge}}
            @canFavorite={{ub.can_favorite}}
            @canFavoriteMoreBadges={{@controller.canFavoriteMoreBadges}}
            @count={{ub.count}}
            @filterUser="true"
            @isFavorite={{ub.is_favorite}}
            @onFavoriteClick={{fn @controller.favorite ub}}
            @username={{@controller.username}}
          />
        {{/each}}
        <PluginOutlet
          @name="after-user-profile-badges"
          @outletArgs={{lazyHash user=@controller.user.model}}
        />
      </div>
    </PluginOutlet>
  </section>
</template>
