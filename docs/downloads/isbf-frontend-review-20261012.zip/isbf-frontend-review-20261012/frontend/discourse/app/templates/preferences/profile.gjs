import { Input } from "@ember/component";
import { array, fn } from "@ember/helper";
import { LinkTo } from "@ember/routing";
import { trustHTML } from "@ember/template";
import PluginOutlet from "discourse/components/plugin-outlet";
import PreferenceCheckbox from "discourse/components/preference-checkbox";
import UppyImageUploader from "discourse/components/uppy-image-uploader";
import UserField from "discourse/components/user-field";
import lazyHash from "discourse/helpers/lazy-hash";
import ComboBox from "discourse/select-kit/components/combo-box";
import TimezoneInput from "discourse/select-kit/components/timezone-input";
import DButton from "discourse/ui-kit/d-button";
import DEditor from "discourse/ui-kit/d-editor";
import DSaveControls from "discourse/ui-kit/d-save-controls";
import dReplaceEmoji from "discourse/ui-kit/helpers/d-replace-emoji";
import { i18n } from "discourse-i18n";

export default <template>
  {{#if @controller.showEnforcedRequiredFieldsNotice}}
    <div class="alert alert-error">{{i18n
        "user.preferences.profile.enforced_required_fields"
      }}</div>
  {{/if}}

  {{#unless @controller.showEnforcedRequiredFieldsNotice}}
    {{#if @controller.siteSettings.allow_users_to_hide_profile}}
      <div
        class="control-group user-hide-profile"
        data-setting-name="user-hide-profile"
      >
        <PreferenceCheckbox
          class="pref-hide-profile"
          data-setting-name="user-hide-profile"
          @checked={{@controller.model.user_option.hide_profile}}
          @labelKey="user.hide_profile"
        />
      </div>
    {{/if}}

    {{#if @controller.canChangeBio}}
      <div class="control-group pref-bio" data-setting-name="user-bio">
        <label class="control-label">{{i18n "user.bio"}}</label>
        <div class="controls bio-composer input-xxlarge">
          <DEditor @value={{@controller.model.bio_raw}} />
        </div>
      </div>
    {{/if}}

    <div class="control-group pref-timezone" data-setting-name="user-timezone">
      <label class="control-label">{{i18n "user.timezone"}}</label>
      <TimezoneInput
        class="input-xxlarge"
        @onChange={{fn (mut @controller.model.user_option.timezone)}}
        @value={{@controller.model.user_option.timezone}}
      />
      <DButton
        class="btn-default"
        @action={{@controller.useCurrentTimezone}}
        @icon="globe"
        @label="user.use_current_timezone"
      />
    </div>

    {{#if @controller.model.can_change_location}}
      <div
        class="control-group pref-location"
        data-setting-name="user-location"
      >
        <label class="control-label" for="edit-location">{{i18n
            "user.location"
          }}</label>
        <div class="controls">
          <Input
            class="input-xxlarge"
            id="edit-location"
            @type="text"
            @value={{@controller.model.location}}
          />
        </div>
      </div>
    {{/if}}

    {{#if @controller.model.can_change_website}}
      <div class="control-group pref-website" data-setting-name="user-website">
        <label class="control-label" for="edit-website">{{i18n
            "user.website"
          }}</label>
        <div class="controls">
          <Input
            class="input-xxlarge"
            id="edit-website"
            @type="text"
            @value={{@controller.model.website}}
          />
        </div>
      </div>
    {{/if}}
  {{/unless}}

  {{#each @controller.userFields as |uf|}}
    <div class="control-group" data-setting-name="user-user-fields">
      <UserField @field={{uf.field}} @value={{uf.value}} />
    </div>
  {{/each}}
  <div class="clearfix"></div>

  {{#unless @controller.showEnforcedRequiredFieldsNotice}}
    {{#if @controller.siteSettings.allow_profile_backgrounds}}
      {{#if @controller.canUploadProfileHeader}}
        <div
          class="control-group pref-profile-bg"
          data-setting-name="user-profile-bg"
        >
          <label class="control-label">{{i18n
              "user.change_profile_background.title"
            }}</label>
          <div class="controls">
            <UppyImageUploader
              @id="profile-background-uploader"
              @imageUrl={{@controller.model.profile_background_upload_url}}
              @onUploadDeleted={{fn
                (mut @controller.model.profile_background_upload_url)
                null
              }}
              @onUploadDone={{@controller.profileBackgroundUploadDone}}
              @type="profile_background"
            />
          </div>
          <div class="instructions">
            {{i18n "user.change_profile_background.instructions"}}
          </div>
        </div>
      {{/if}}
      {{#if @controller.canUploadUserCardBackground}}
        <div
          class="control-group pref-profile-bg"
          data-setting-name="user-card-bg"
        >
          <label class="control-label">{{i18n
              "user.change_card_background.title"
            }}</label>
          <div class="controls">
            <UppyImageUploader
              @id="profile-card-background-uploader"
              @imageUrl={{@controller.model.card_background_upload_url}}
              @onUploadDeleted={{fn
                (mut @controller.model.card_background_upload_url)
                null
              }}
              @onUploadDone={{@controller.cardBackgroundUploadDone}}
              @type="card_background"
            />
          </div>
          <div class="instructions">
            {{i18n "user.change_card_background.instructions"}}
          </div>
        </div>
      {{/if}}
    {{/if}}

    {{#if @controller.siteSettings.allow_featured_topic_on_user_profiles}}
      <div class="control-group" data-setting-name="user-featured-topic">
        <label class="control-label">{{i18n "user.featured_topic"}}</label>
        {{#if @controller.model.featured_topic}}
          <label class="featured-topic-link">
            <LinkTo
              @models={{array
                @controller.model.featured_topic.slug
                @controller.model.featured_topic.id
              }}
              @route="topic"
            >
              {{dReplaceEmoji
                (trustHTML @controller.model.featured_topic.fancy_title)
              }}
            </LinkTo>
          </label>
        {{/if}}

        <div>
          <DButton
            class="btn-default feature-topic-on-profile-btn"
            @action={{@controller.showFeaturedTopicModal}}
            @label="user.feature_topic_on_profile.open_search"
          />
          {{#if @controller.model.featured_topic}}
            <DButton
              class="btn-danger clear-feature-topic-on-profile-btn"
              @action={{@controller.clearFeaturedTopicFromProfile}}
              @label="user.feature_topic_on_profile.clear.title"
            />
          {{/if}}
        </div>
        <div class="instructions">
          {{i18n "user.change_featured_topic.instructions"}}
        </div>
      </div>
    {{/if}}

    {{#if @controller.canChangeDefaultCalendar}}
      <div class="control-group" data-setting-name="user-default-calendar">
        <label class="control-label">{{i18n
            "download_calendar.default_calendar"
          }}</label>
        <div>
          <ComboBox
            @content={{@controller.calendarOptions}}
            @id="user-default-calendar"
            @onChange={{fn
              (mut @controller.model.user_option.default_calendar)
            }}
            @value={{@controller.model.user_option.default_calendar}}
            @valueProperty="value"
          />
        </div>
        <div class="instructions">
          {{i18n "download_calendar.default_calendar_instruction"}}
        </div>
      </div>
    {{/if}}

    <PluginOutlet
      @connectorTagName="div"
      @name="user-preferences-profile"
      @outletArgs={{lazyHash model=@controller.model save=@controller.save}}
    />

    <PluginOutlet
      @connectorTagName="div"
      @name="user-custom-preferences"
      @outletArgs={{lazyHash model=@controller.model}}
    />

    <PluginOutlet
      @connectorTagName="div"
      @name="user-custom-controls"
      @outletArgs={{lazyHash model=@controller.model}}
    />
  {{/unless}}

  <DSaveControls
    @action={{@controller.save}}
    @model={{@controller.model}}
    @saved={{@controller.saved}}
  />
</template>
