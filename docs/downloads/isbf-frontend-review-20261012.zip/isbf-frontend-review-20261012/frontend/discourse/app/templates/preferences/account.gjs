import { fn, get, hash } from "@ember/helper";
import { on } from "@ember/modifier";
import { LinkTo } from "@ember/routing";
import EmailDropdown from "discourse/components/email-dropdown";
import GoogleIcon from "discourse/components/google-icon";
import PluginOutlet from "discourse/components/plugin-outlet";
import UsernamePreference from "discourse/components/username-preference";
import lazyHash from "discourse/helpers/lazy-hash";
import routeAction from "discourse/helpers/route-action";
import ComboBox from "discourse/select-kit/components/combo-box";
import FlairChooser from "discourse/select-kit/components/flair-chooser";
import { or } from "discourse/truth-helpers";
import DButton from "discourse/ui-kit/d-button";
import DSaveControls from "discourse/ui-kit/d-save-controls";
import DTextField from "discourse/ui-kit/d-text-field";
import DUserStatusMessage from "discourse/ui-kit/d-user-status-message";
import dBoundAvatar from "discourse/ui-kit/helpers/d-bound-avatar";
import dDasherize from "discourse/ui-kit/helpers/d-dasherize";
import dIcon from "discourse/ui-kit/helpers/d-icon";
import { i18n } from "discourse-i18n";

export default <template>
  <div class="control-group pref-username" data-setting-name="user-username">
    <label class="control-label">{{i18n "user.username.title"}}</label>
    <UsernamePreference @user={{@controller.model}} />
  </div>

  {{#unless
    (or
      @controller.siteSettings.discourse_connect_overrides_avatar
      @controller.siteSettings.auth_overrides_avatar
    )
  }}
    <div class="control-group pref-avatar" data-setting-name="user-avatar">
      <label class="control-label" id="profile-picture">{{i18n
          "user.avatar.title"
        }}</label>
      <input
        data-custom-avatar-upload-id={{@controller.model.custom_avatar_upload_id}}
        data-system-avatar-upload-id={{@controller.model.system_avatar_upload_id}}
        id="user-avatar-uploads"
        type="hidden"
      />
      <div class="controls">
        {{! we want the "huge" version even though we're downsizing it in CSS }}
        {{dBoundAvatar @controller.model "huge"}}
        <DButton
          class="btn-default pad-left"
          id="edit-avatar"
          @action={{fn (routeAction "showAvatarSelector") @controller.model}}
          @icon="pencil"
        />
      </div>
    </div>
  {{/unless}}

  {{#if @controller.canCheckEmails}}
    <div class="control-group pref-email" data-setting-name="user-email">
      <label class="control-label">{{i18n "user.email.title"}}</label>
      {{#if @controller.model.email}}
        {{#if @controller.siteSettings.enable_secondary_emails}}
          <div class="emails">
            {{#each @controller.emails as |email|}}
              <div class="row email">
                <div class="email-first">{{email.email}}</div>
                <div class="email-second">
                  {{#if email.primary}}
                    <span class="primary">
                      {{i18n "user.email.primary_label"}}
                    </span>
                  {{/if}}
                  {{#unless email.confirmed}}
                    <span class="unconfirmed">
                      {{i18n "user.email.unconfirmed_label"}}
                    </span>
                    &bull;
                    {{#if email.resending}}
                      <span>{{i18n "user.email.resending_label"}}</span>
                    {{else if email.resent}}
                      <span>{{i18n "user.email.resent_label"}}</span>
                    {{else}}
                      <button
                        class="resend-email-confirmation"
                        type="button"
                        {{on
                          "click"
                          (fn @controller.resendConfirmationEmail email)
                        }}
                      >
                        {{i18n "user.email.resend_label"}}
                      </button>
                    {{/if}}
                  {{/unless}}
                </div>
                {{#if @controller.model.can_edit_email}}
                  <EmailDropdown
                    @destroyEmail={{@controller.destroyEmail}}
                    @email={{email}}
                    @setPrimaryEmail={{@controller.setPrimaryEmail}}
                  />
                {{/if}}
              </div>
            {{/each}}
          </div>

          {{#if @controller.canAddEmail}}
            <div class="controls">
              <LinkTo @query={{hash new=1}} @route="preferences.email">
                {{dIcon "plus"}}
                {{i18n "user.email.add_email"}}
              </LinkTo>
            </div>
          {{/if}}
        {{else}}
          <div class="controls">
            <span class="static">{{@controller.model.email}}</span>
            {{#if @controller.model.can_edit_email}}
              <LinkTo
                class="btn btn-default btn-small btn-icon pad-left no-text"
                @route="preferences.email"
              >
                {{dIcon "pencil"}}
              </LinkTo>
            {{/if}}
          </div>
        {{/if}}

        <div class="instructions">
          {{#if @controller.siteSettings.auth_overrides_email}}
            {{i18n "user.email.auth_override_instructions"}}
          {{/if}}
          {{i18n "user.email.instructions"}}
        </div>
      {{else}}
        <div class="controls">
          <DButton
            class="btn-default"
            @action={{fn (routeAction "checkEmail") @controller.model}}
            @icon="envelope"
            @label="admin.users.check_email.text"
            @title="admin.users.check_email.title"
          />
        </div>
      {{/if}}
    </div>
  {{/if}}

  <span>
    <PluginOutlet
      @name="user-preferences-account-after-email"
      @outletArgs={{lazyHash email=@controller.model.email}}
    />
  </span>

  {{#if @controller.canUpdateAssociatedAccounts}}
    <div
      class="control-group pref-associated-accounts"
      data-setting-name="user-associated-accounts"
    >
      <label class="control-label">{{i18n
          "user.associated_accounts.title"
        }}</label>
      {{#if @controller.associatedAccountsLoaded}}
        <table class="associated-accounts">
          <tbody>
            {{#each @controller.authProviders as |authProvider|}}
              {{#if authProvider.account}}
                <tr
                  class="{{dDasherize authProvider.method.name}}
                    account-connected"
                >
                  <td class="associated-account__icon">
                    {{#if authProvider.method.isGoogle}}
                      <GoogleIcon />
                    {{else}}
                      {{dIcon (or authProvider.method.icon "user")}}
                    {{/if}}
                  </td>
                  <td>
                    <div class="associated-account__name">
                      {{#if authProvider.method.provider_url}}
                        <a
                          href={{authProvider.method.provider_url}}
                          rel="noopener noreferrer"
                          target="_blank"
                        >
                          {{authProvider.method.prettyName}}
                        </a>
                      {{else}}
                        {{authProvider.method.prettyName}}
                      {{/if}}
                    </div>
                    <div class="associated-account__description">
                      {{authProvider.account.description}}
                    </div>
                  </td>
                  <td class="associated-account__actions">
                    {{#if authProvider.method.can_revoke}}
                      <DButton
                        class="btn-danger no-text"
                        @action={{fn
                          @controller.revokeAccount
                          authProvider.account
                        }}
                        @disabled={{get
                          @controller.revoking
                          authProvider.method.name
                        }}
                        @icon="trash-can"
                        @title="user.associated_accounts.revoke"
                      />
                    {{/if}}
                  </td>
                </tr>
              {{else}}
                <tr class={{dDasherize authProvider.method.name}}>
                  <td
                    class="associated-account__icon
                      {{dDasherize authProvider.method.name}}"
                  >
                    {{#if authProvider.method.isGoogle}}
                      <GoogleIcon />
                    {{else}}
                      {{dIcon (or authProvider.method.icon "user")}}
                    {{/if}}
                  </td>
                  <td>
                    <div class="associated-account__name">
                      {{#if authProvider.method.provider_url}}
                        <a
                          href={{authProvider.method.provider_url}}
                          rel="noopener noreferrer"
                          target="_blank"
                        >
                          {{authProvider.method.prettyName}}
                        </a>
                      {{else}}
                        {{authProvider.method.prettyName}}
                      {{/if}}
                    </div>
                    <div class="associated-account__description">
                      {{authProvider.account.description}}
                    </div>
                  </td>
                  <td class="associated-account__actions">
                    {{#if authProvider.method.can_connect}}
                      <DButton
                        class="btn-primary"
                        @action={{fn
                          @controller.connectAccount
                          authProvider.method
                        }}
                        @disabled={{@controller.disableConnectButtons}}
                        @icon="plug"
                        @label="user.associated_accounts.connect"
                      />
                    {{else}}
                      {{i18n "user.associated_accounts.not_connected"}}
                    {{/if}}
                  </td>
                </tr>
              {{/if}}
            {{/each}}
          </tbody>
        </table>
      {{else}}
        <div class="controls">
          <DButton
            @action={{fn (routeAction "checkEmail") @controller.model}}
            @icon="envelope"
            @label="admin.users.check_email.text"
            @title="admin.users.check_email.title"
          />
        </div>
      {{/if}}
    </div>
  {{/if}}

  {{#if @controller.canEditName}}
    <div class="control-group pref-name" data-setting-name="user-name">
      <label class="control-label">{{i18n "user.name.title"}}</label>
      <div class="controls">
        {{#if @controller.model.can_edit_name}}
          <DTextField
            @classNames="input-xxlarge"
            @maxlength="255"
            @value={{@controller.newNameInput}}
          />
        {{else}}
          <span class="static">{{@controller.model.name}}</span>
        {{/if}}
      </div>
      <div class="instructions">
        {{@controller.nameInstructions}}
      </div>

      <PluginOutlet
        @name="user-preferences-account-after-name"
        @outletArgs={{lazyHash name=@controller.model.name}}
      />
    </div>
  {{/if}}

  {{#if @controller.canSelectTitle}}
    <div class="control-group pref-title" data-setting-name="user-title">
      <label class="control-label">{{i18n "user.title.title"}}</label>
      <div class="controls">
        <ComboBox
          @content={{@controller.model.availableTitles}}
          @onChange={{fn (mut @controller.newTitleInput)}}
          @options={{hash none="user.title.none"}}
          @value={{@controller.newTitleInput}}
        />
      </div>
      <div class="instructions">
        {{i18n "user.title.instructions"}}
      </div>
    </div>
  {{/if}}

  {{#if @controller.canSelectFlair}}
    <div class="control-group pref-flair" data-setting-name="user-flair">
      <label class="control-label">{{i18n "user.flair.title"}}</label>
      <div class="controls">
        <FlairChooser
          @content={{@controller.model.availableFlairs}}
          @onChange={{fn (mut @controller.newFlairGroupId)}}
          @options={{hash none="user.flair.none"}}
          @value={{@controller.newFlairGroupId}}
        />
      </div>
      <div class="instructions">
        {{i18n "user.flair.instructions"}}
      </div>
    </div>
  {{/if}}

  {{#if @controller.canSelectUserStatus}}
    <div class="control-group pref-user-status" data-setting-name="user-status">
      <label class="control-label">{{i18n "user.status.title"}}</label>
      <div class="controls">
        {{#if @controller.newStatus}}
          <DUserStatusMessage
            @showDescription={{true}}
            @status={{@controller.newStatus}}
          />
        {{else}}
          <span class="static">{{i18n "user.status.not_set"}}</span>
        {{/if}}
        <DButton
          class="btn-default btn-small pad-left"
          @action={{fn @controller.showUserStatusModal @controller.newStatus}}
          @icon="pencil"
        />
      </div>
    </div>
  {{/if}}

  {{#if @controller.canSelectPrimaryGroup}}
    <div
      class="control-group pref-primary-group"
      data-setting-name="user-primary-group"
    >
      <label class="control-label">{{i18n "user.primary_group.title"}}</label>
      <div class="controls">
        <ComboBox
          @content={{@controller.model.filteredGroups}}
          @options={{hash none="user.primary_group.none"}}
          @value={{@controller.newPrimaryGroupInput}}
        />
      </div>
    </div>
  {{/if}}

  {{#if @controller.canDownloadPosts}}
    <div
      class="control-group pref-data-export"
      data-setting-name="user-data-export"
    >
      <label class="control-label">{{i18n
          "user.download_archive.title"
        }}</label>
      <div class="controls">
        <DButton
          class="btn-default btn-request-archive"
          @action={{@controller.exportUserArchive}}
          @icon="download"
          @label="user.download_archive.button_text"
        />
      </div>
      <div class="instructions">
        {{i18n "user.download_archive.description"}}
      </div>
    </div>
  {{/if}}

  <span>
    <PluginOutlet
      @connectorTagName="div"
      @name="user-preferences-account"
      @outletArgs={{lazyHash model=@controller.model save=@controller.save}}
    />
  </span>

  <br />

  <span>
    <PluginOutlet
      @connectorTagName="div"
      @name="user-custom-controls"
      @outletArgs={{lazyHash model=@controller.model}}
    />
  </span>

  {{#if @controller.canSaveUser}}
    <DSaveControls
      @action={{@controller.save}}
      @model={{@controller.model}}
      @saved={{@controller.saved}}
    />
  {{/if}}

  {{#if @controller.model.canDeleteAccount}}
    <div class="control-group delete-account">
      <br />
      <div class="controls">
        <DButton
          class="btn-danger"
          @action={{@controller.delete}}
          @disabled={{@controller.deleteDisabled}}
          @icon="trash-can"
          @label="user.delete_account"
        />
      </div>
    </div>
  {{/if}}
</template>
