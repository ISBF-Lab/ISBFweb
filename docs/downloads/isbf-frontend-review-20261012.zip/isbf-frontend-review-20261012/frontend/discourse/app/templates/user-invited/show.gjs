import { concat, fn } from "@ember/helper";
import { LinkTo } from "@ember/routing";
import { trustHTML } from "@ember/template";
import SvgEnvelopeZero from "discourse/components/svg/envelope-zero";
import DMenu from "discourse/float-kit/components/d-menu";
import bodyClass from "discourse/helpers/body-class";
import rawDate from "discourse/helpers/raw-date";
import { groupPath } from "discourse/lib/url";
import DButton from "discourse/ui-kit/d-button";
import DConditionalLoadingSpinner from "discourse/ui-kit/d-conditional-loading-spinner";
import DCopyButton from "discourse/ui-kit/d-copy-button";
import DDropdownMenu from "discourse/ui-kit/d-dropdown-menu";
import DEmptyState from "discourse/ui-kit/d-empty-state";
import DLoadMore from "discourse/ui-kit/d-load-more";
import DTextField from "discourse/ui-kit/d-text-field";
import dAvatar from "discourse/ui-kit/helpers/d-avatar";
import dConcatClass from "discourse/ui-kit/helpers/d-concat-class";
import dFormatDate from "discourse/ui-kit/helpers/d-format-date";
import dFormatDuration from "discourse/ui-kit/helpers/d-format-duration";
import dIcon from "discourse/ui-kit/helpers/d-icon";
import dNumber from "discourse/ui-kit/helpers/d-number";
import { i18n } from "discourse-i18n";

export default <template>
  {{bodyClass "user-invites-page"}}

  {{#if @controller.canInviteToForum}}
    <DLoadMore
      class={{dConcatClass
        "user-content"
        (if @controller.hasLoadedInitialInvites "--loaded")
      }}
      @action={{@controller.loadMore}}
      @id="user-content"
    >
      <section class="user-additional-controls">
        {{#if @controller.showSearch}}
          <div class="user-invite-search">
            <form>
              <DTextField
                @placeholderKey="user.invited.search"
                @value={{@controller.searchTerm}}
              /></form>
          </div>
        {{/if}}
        <section class="user-invite-buttons">
          {{#if @controller.model.invites}}
            {{#if @controller.canCreateInvite}}
              <DButton
                class="btn-default invite-button"
                @action={{@controller.createInvite}}
                @icon="plus"
                @label="user.invited.create"
              />
            {{/if}}
            {{#if @controller.canBulkInvite}}
              {{#if @controller.siteSettings.allow_bulk_invite}}
                {{#if @controller.site.desktopView}}
                  <DButton
                    class="btn-default"
                    @action={{@controller.createInviteCsv}}
                    @icon="upload"
                    @label="user.invited.bulk_invite.text"
                  />
                {{/if}}
              {{/if}}
            {{/if}}
          {{/if}}
          {{#if @controller.showBulkActionButtons}}
            {{#if @controller.inviteExpired}}
              <DButton
                class="btn-default bulk-remove-expired"
                @action={{@controller.destroyAllExpired}}
                @icon="xmark"
                @label="user.invited.remove_all"
              />
            {{/if}}

            {{#if @controller.invitePending}}
              {{#if @controller.reinvitedAll}}
                <span class="reinvited-all">
                  <DButton
                    @disabled={{true}}
                    @icon="check"
                    @label="user.invited.reinvited_all"
                  />
                </span>
              {{else if @controller.hasEmailInvites}}
                <DButton
                  class="btn-default"
                  @action={{@controller.reinviteAll}}
                  @icon="arrows-rotate"
                  @label="user.invited.reinvite_all"
                />
              {{/if}}
            {{/if}}
          {{/if}}
        </section>
      </section>
      <section>
        {{#if @controller.model.invites}}
          {{#if @controller.inviteRedeemed}}
            <table class="d-table user-invite-list">
              <thead class="d-table__header">
                <tr class="d-table__row">
                  <th class="d-table__header-cell">{{i18n
                      "user.invited.user"
                    }}</th>
                  <th class="d-table__header-cell">{{i18n
                      "user.invited.redeemed_at"
                    }}</th>
                  {{#if @controller.model.can_see_invite_details}}
                    <th class="d-table__header-cell">{{i18n
                        "user.last_seen"
                      }}</th>
                    <th class="d-table__header-cell">{{i18n
                        "user.invited.topics_entered"
                      }}</th>
                    <th class="d-table__header-cell">{{i18n
                        "user.invited.posts_read_count"
                      }}</th>
                    <th class="d-table__header-cell">{{i18n
                        "user.invited.time_read"
                      }}</th>
                    <th class="d-table__header-cell">{{i18n
                        "user.invited.days_visited"
                      }}</th>
                    <th class="d-table__header-cell">{{i18n
                        "user.invited.invited_via"
                      }}</th>
                  {{/if}}
                </tr>
              </thead>
              <tbody class="d-table__body">
                {{#each @controller.model.invites as |invite|}}
                  <tr class="d-table__row">
                    <td class="d-table__cell --overview">
                      <LinkTo @model={{invite.user}} @route="user">{{dAvatar
                          invite.user
                          imageSize="tiny"
                        }}</LinkTo>
                      <LinkTo
                        @model={{invite.user}}
                        @route="user"
                      >{{invite.user.username}}</LinkTo>
                    </td>
                    <td class="d-table__cell --detail">
                      <div class="d-table__mobile-label">
                        {{i18n "user.invited.redeemed_at"}}
                      </div>
                      {{dFormatDate invite.redeemed_at}}
                    </td>
                    {{#if @controller.model.can_see_invite_details}}
                      <td class="d-table__cell --detail">
                        <div class="d-table__mobile-label">
                          {{i18n "user.last_seen"}}
                        </div>
                        {{dFormatDate invite.user.last_seen_at}}
                      </td>
                      <td class="d-table__cell --detail">
                        <div class="d-table__mobile-label">
                          {{i18n "user.invited.topics_entered"}}
                        </div>
                        {{dNumber invite.user.topics_entered}}
                      </td>
                      <td class="d-table__cell --detail">
                        <div class="d-table__mobile-label">
                          {{i18n "user.invited.posts_read_count"}}
                        </div>
                        {{dNumber invite.user.posts_read_count}}
                      </td>
                      <td class="d-table__cell --detail">
                        <div class="d-table__mobile-label">
                          {{i18n "user.invited.time_read"}}
                        </div>
                        {{dFormatDuration invite.user.time_read}}
                      </td>
                      <td class="d-table__cell --detail">
                        <div class="d-table__mobile-label">
                          {{i18n "user.invited.days_visited"}}
                        </div>
                        <div>
                          <span
                            title={{i18n "user.invited.days_visited"}}
                          >{{trustHTML invite.user.days_visited}}</span>
                          /
                          <span
                            title={{i18n "user.invited.account_age_days"}}
                          >{{trustHTML invite.user.days_since_created}}</span>
                        </div>
                      </td>
                      <td class="d-table__cell --detail">
                        <div class="d-table__mobile-label">
                          {{i18n "user.invited.invited_via"}}
                        </div>
                        {{trustHTML invite.invite_source}}
                      </td>
                    {{/if}}
                  </tr>
                {{/each}}
              </tbody>
            </table>
          {{else}}
            <table class="d-table user-invite-list">
              <thead class="d-table__header">
                <tr class="d-table__row">
                  <th class="d-table__header-cell">{{i18n
                      "user.invited.invited_via"
                    }}</th>
                  <th class="d-table__header-cell">{{i18n
                      "user.invited.sent"
                    }}</th>
                  <th class="d-table__header-cell">{{i18n
                      "user.invited.expires_at"
                    }}</th>
                  <th class="d-table__header-cell"></th>
                </tr>
              </thead>
              <tbody class="d-table__body">
                {{#each @controller.model.invites as |invite|}}
                  <tr class="d-table__row">
                    <td class="d-table__cell --overview invite-type">
                      <div class="invite-shortkey">
                        {{#if invite.link}}
                          <input
                            class="invite-link-target"
                            disabled={{true}}
                            id={{concat "invite-link-" invite.id}}
                            type="text"
                            value={{invite.link}}
                          />
                        {{/if}}
                        {{#if invite.email}}
                          {{dIcon "envelope"}}
                          {{invite.email}}
                        {{else}}
                          {{dIcon "link"}}
                          {{#if invite.invite_key}}
                            {{i18n
                              "user.invited.invited_via_link"
                              key=invite.shortKey
                              count=invite.redemption_count
                              max=invite.max_redemptions_allowed
                            }}
                          {{else}}
                            <em>{{i18n "user.invited.generating_link"}}</em>
                          {{/if}}
                        {{/if}}
                      </div>

                      <div class="invite-details">
                        {{#if invite.description}}
                          <div class="invite-description">
                            {{invite.description}}
                          </div>
                        {{/if}}

                        <div class="invite-groups">
                          {{#each invite.groups as |g|}}
                            <span class="invite-extra">
                              <a
                                class="invite-extra-item-link"
                                href={{groupPath g.name}}
                              >{{dIcon "users"}}
                                {{g.name}}
                              </a>
                            </span>
                          {{/each}}
                        </div>

                        {{#if invite.topic}}
                          <span class="invite-extra invite-topic">
                            <a
                              class="invite-extra-item-link"
                              href={{invite.topic.url}}
                            >
                              {{dIcon "file-lines"}}
                              {{invite.topic.title}}
                            </a>
                          </span>
                        {{/if}}
                      </div>
                    </td>

                    <td class="d-table__cell --detail invite-updated-at">
                      <div class="d-table__mobile-label">
                        {{i18n "user.invited.sent"}}
                      </div>
                      {{dFormatDate invite.updated_at}}
                    </td>

                    <td class="d-table__cell --detail invite-expires-at">
                      <div class="d-table__mobile-label">
                        {{i18n "user.invited.expires_at"}}
                      </div>
                      {{#if @controller.inviteExpired}}
                        {{rawDate invite.expires_at}}
                      {{else if invite.expired}}
                        {{i18n "user.invited.expired"}}
                      {{else}}
                        {{rawDate invite.expires_at}}
                      {{/if}}
                    </td>

                    {{#if invite.can_delete_invite}}
                      <td class="d-table__cell --controls invite-actions">
                        <div class="d-table__cell-actions">
                          <DButton
                            class="btn-default btn-small edit-invite"
                            @action={{fn @controller.editInvite invite}}
                            @label="user.invited.edit"
                            @title="user.invited.edit"
                          />
                          <DMenu
                            class="btn-default btn-small"
                            @icon="ellipsis-vertical"
                            @identifier="invites-menu"
                            @onRegisterApi={{@controller.onRegisterApi}}
                            @title={{i18n "more_options"}}
                          >
                            <:content>
                              <DDropdownMenu as |dropdown|>
                                <dropdown.item>
                                  <DButton
                                    class="btn-transparent --danger"
                                    @action={{fn
                                      @controller.destroyInvite
                                      invite
                                    }}
                                    @icon="trash-can"
                                    @label={{if
                                      invite.destroyed
                                      "user.invited.removed"
                                      "user.invited.remove"
                                    }}
                                  />
                                </dropdown.item>
                                {{#if invite.link}}
                                  <dropdown.item>
                                    <DCopyButton
                                      @copyClass="btn-transparent"
                                      @icon="copy"
                                      @selector={{concat
                                        "#invite-link-"
                                        invite.id
                                      }}
                                      @translatedLabel={{i18n
                                        "user.invited.invite.copy_link"
                                      }}
                                      @translatedLabelAfterCopy={{i18n
                                        "user.invited.invite.link_copied"
                                      }}
                                    />
                                  </dropdown.item>
                                {{/if}}
                              </DDropdownMenu>
                            </:content>
                          </DMenu>
                        </div>
                      </td>
                    {{/if}}
                  </tr>
                {{/each}}
              </tbody>
            </table>
          {{/if}}

          <DConditionalLoadingSpinner
            @condition={{@controller.invitesLoading}}
          />
        {{else}}
          <DEmptyState
            @ctaAction={{if
              @controller.canCreateInvite
              @controller.createInvite
            }}
            @ctaLabel={{if
              @controller.canCreateInvite
              (i18n "user.invited.none.cta")
            }}
            @identifier="empty-channels-list"
            @svgContent={{SvgEnvelopeZero}}
            @tipIcon={{if @controller.canBulkInvite "upload"}}
            @title={{i18n "user.invited.none.title"}}
          >
            <:tip>
              {{#if @controller.canBulkInvite}}
                {{i18n "user.invited.none.tip.prefix"}}
                <DButton
                  class="btn-link"
                  @action={{@controller.createInviteCsv}}
                  @label="user.invited.none.tip.action"
                />
                {{i18n "user.invited.none.tip.suffix"}}
              {{/if}}
            </:tip>
          </DEmptyState>
        {{/if}}
      </section>
    </DLoadMore>
  {{else}}
    <div class="alert alert-error invite-error">
      {{@controller.model.error}}
    </div>
  {{/if}}
</template>
