/* eslint-disable ember/no-observers */
import { array, fn, hash } from "@ember/helper";
import { on } from "@ember/modifier";
import EmberObject, { action, computed, set } from "@ember/object";
import { LinkTo } from "@ember/routing";
import { dasherize } from "@ember/string";
import { trustHTML } from "@ember/template";
import { compare, isEmpty } from "@ember/utils";
import {
  attributeBindings,
  classNameBindings,
  classNames,
} from "@ember-decorators/component";
import { observes, on as onEvent } from "@ember-decorators/object";
import CardContentsBase from "discourse/components/card-contents-base";
import PluginOutlet from "discourse/components/plugin-outlet";
import UserBadge from "discourse/components/user-badge";
import formatUsername from "discourse/helpers/format-username";
import lazyHash from "discourse/helpers/lazy-hash";
import userStatus from "discourse/helpers/user-status";
import CanCheckEmailsHelper from "discourse/lib/can-check-emails-helper";
import { durationTiny } from "discourse/lib/formatter";
import { getURLWithCDN } from "discourse/lib/get-url";
import { wantsNewWindow } from "discourse/lib/intercept-click";
import { prioritizeNameInUx } from "discourse/lib/settings";
import { emojiUnescape } from "discourse/lib/text";
import { escapeExpression } from "discourse/lib/utilities";
import User from "discourse/models/user";
import DButton from "discourse/ui-kit/d-button";
import DHtmlWithLinks from "discourse/ui-kit/d-html-with-links";
import DUserAvatarFlair from "discourse/ui-kit/d-user-avatar-flair";
import dBoundAvatar from "discourse/ui-kit/helpers/d-bound-avatar";
import dFormatDate from "discourse/ui-kit/helpers/d-format-date";
import dFormatDuration from "discourse/ui-kit/helpers/d-format-duration";
import dIcon from "discourse/ui-kit/helpers/d-icon";
import dReplaceEmoji from "discourse/ui-kit/helpers/d-replace-emoji";
import { i18n } from "discourse-i18n";

@classNames("user-card")
@classNameBindings(
  "visible:show",
  "showBadges",
  "user.card_background_upload_url::no-bg",
  "isFixed:fixed",
  "usernameClass",
  "primaryGroup"
)
@attributeBindings("ariaLabel:aria-label")
export default class UserCardContents extends CardContentsBase {
  elementId = "user-card";
  avatarSelector = "[data-user-card]";
  avatarDataAttrKey = "userCard";
  mentionSelector = "a.mention";
  ariaLabel = i18n("user.card");

  user = null;

  // If inside a topic
  topicPostCount = null;

  @computed("topic.postStream")
  get postStream() {
    return this.topic?.postStream;
  }

  set postStream(value) {
    set(this, "topic.postStream", value);
  }

  @computed("siteSettings.allow_profile_backgrounds")
  get allowBackgrounds() {
    return this.siteSettings.allow_profile_backgrounds;
  }

  @computed("siteSettings.enable_badges")
  get showBadges() {
    return this.siteSettings.enable_badges;
  }

  @computed("siteSettings.display_local_time_in_user_card")
  get showUserLocalTime() {
    return this.siteSettings.display_local_time_in_user_card;
  }

  @computed("siteSettings.moderators_view_emails")
  get canModeratorsViewEmails() {
    return this.siteSettings.moderators_view_emails;
  }

  @computed("topicPostCount")
  get enoughPostsForFiltering() {
    return this.topicPostCount >= 2;
  }

  @computed(
    "viewingTopic",
    "postStream.hasNoFilters",
    "enoughPostsForFiltering"
  )
  get showFilter() {
    return (
      this.viewingTopic &&
      this.postStream?.hasNoFilters &&
      this.enoughPostsForFiltering
    );
  }

  @computed("postStream.userFilters.length")
  get hasUserFilters() {
    return this.postStream?.userFilters?.length > 0;
  }

  @computed("moreBadgesCount")
  get showMoreBadges() {
    return this.moreBadgesCount > 0;
  }

  @computed("viewingAdmin", "showName", "user.canBeDeleted")
  get showDelete() {
    return this.viewingAdmin && this.showName && this.user?.canBeDeleted;
  }

  @computed("user.isBasic")
  get linkWebsite() {
    return !this.user?.isBasic;
  }

  @computed("user.suspend_reason", "user.silence_reason")
  get isRestricted() {
    return this.user?.suspend_reason || this.user?.silence_reason;
  }

  @computed("isRestricted", "user.bio_excerpt")
  get isRestrictedOrHasBio() {
    return this.isRestricted || this.user?.bio_excerpt;
  }

  @computed("user.staged", "canCheckEmails")
  get showCheckEmail() {
    return this.user?.staged && this.canCheckEmails;
  }

  @computed(
    "user.featured_topic",
    "siteSettings.allow_featured_topic_on_user_profiles"
  )
  get showFeaturedTopic() {
    return (
      this.user?.featured_topic &&
      this.siteSettings?.allow_featured_topic_on_user_profiles
    );
  }

  @computed("user.name", "user.username")
  get showName() {
    return this.user.name !== this.user.username;
  }

  @computed("user.id", "currentUser.id")
  get isOwnCard() {
    return this.currentUser && this.user.id === this.currentUser.id;
  }

  @computed("user.username_lower", "isOwnCard")
  get avatarUrl() {
    if (this.isOwnCard) {
      return `/u/${this.user.username_lower}/preferences/account`;
    }
    return this.user.path;
  }

  @computed("model.id", "currentUser.id")
  get canCheckEmails() {
    return new CanCheckEmailsHelper(
      this.model,
      this.canModeratorsViewEmails,
      this.currentUser
    ).canCheckEmails;
  }

  @computed("user")
  get hasLocaleOrWebsite() {
    return this.user.location || this.user.website_name || this.userTimezone;
  }

  @computed("user.status")
  get hasStatus() {
    return this.siteSettings.enable_user_status && this.user.status;
  }

  @computed("user.status.emoji")
  get userStatusEmoji() {
    return emojiUnescape(escapeExpression(`:${this.user?.status?.emoji}:`));
  }

  @computed("user.staff")
  get staff() {
    return this.user?.staff ? "staff" : "";
  }

  @computed("user.trust_level")
  get newUser() {
    return this.user?.trust_level === 0 ? "new-user" : "";
  }

  @computed("user.name")
  get nameFirst() {
    return prioritizeNameInUx(this.user?.name);
  }

  @computed("user")
  get userTimezone() {
    if (!this.showUserLocalTime) {
      return;
    }
    return this.user.get("user_option.timezone");
  }

  @computed("userTimezone")
  get formattedUserLocalTime() {
    return moment.tz(this.userTimezone).format(i18n("dates.time"));
  }

  @computed("username")
  get usernameClass() {
    return this.username ? `user-card-${this.username}` : "";
  }

  @computed("topicPostCount")
  get filterPostsLabel() {
    return i18n("topic.filter_to", { count: this.topicPostCount });
  }

  @computed("user.user_fields.@each.value")
  get publicUserFields() {
    const siteUserFields = this.site.get("user_fields");
    if (!isEmpty(siteUserFields)) {
      const userFields = this.get("user.user_fields");
      return siteUserFields
        .filter((field) => field.show_on_user_card)
        .sort((a, b) => compare(a?.position, b?.position))
        .map((field) => {
          set(field, "dasherized_name", dasherize(field.get("name")));
          const value = userFields ? userFields[field.get("id")] : null;
          return isEmpty(value) ? null : EmberObject.create({ value, field });
        })
        .filter((item) => item != null);
    }
  }

  @computed("user.trust_level")
  get removeNoFollow() {
    return this.user?.trust_level > 2 && !this.siteSettings.tl3_links_no_follow;
  }

  @computed("user.badge_count", "user.featured_user_badges.length")
  get moreBadgesCount() {
    return this.user?.badge_count - this.user?.featured_user_badges?.length;
  }

  @computed("user.time_read", "user.recent_time_read")
  get showRecentTimeRead() {
    return (
      this.user?.time_read !== this.user?.recent_time_read &&
      this.user?.recent_time_read !== 0
    );
  }

  @computed("user.recent_time_read")
  get recentTimeRead() {
    return durationTiny(this.user?.recent_time_read);
  }

  @computed("showRecentTimeRead", "user.time_read", "recentTimeRead")
  get timeReadTooltip() {
    if (this.showRecentTimeRead) {
      return i18n("time_read_recently_tooltip", {
        time_read: durationTiny(this.user?.time_read),
        recent_time_read: this.recentTimeRead,
      });
    } else {
      return i18n("time_read_tooltip", {
        time_read: durationTiny(this.user?.time_read),
      });
    }
  }

  @computed("user.primary_group_name")
  get primaryGroup() {
    return `group-${this.user?.primary_group_name}`;
  }

  @computed("user.profile_hidden", "user.inactive")
  get contentHidden() {
    return this.user?.profile_hidden || this.user?.inactive;
  }

  @observes("user.card_background_upload_url")
  addBackground() {
    if (!this.allowBackgrounds) {
      return;
    }

    if (!this.element) {
      return;
    }

    const url = this.get("user.card_background_upload_url");
    const bg = isEmpty(url) ? "" : `url(${getURLWithCDN(url)})`;
    this.element.style.backgroundImage = bg;
  }

  cleanUp() {
    this._close();
  }

  @action
  refreshRoute(value) {
    this.router.transitionTo({ queryParams: { name: value } });
  }

  @action
  handleShowUser(event) {
    if (wantsNewWindow(event)) {
      return;
    }

    event.preventDefault();
    // Invokes `showUser` argument. Convert to `this.args.showUser` when
    // refactoring this to a glimmer component.
    this.showUser(this.user);
    this._close();
  }

  @action
  close() {
    this._close();
  }

  @action
  composePM(user, post) {
    this._close();
    this.composePrivateMessage(user, post);
  }

  @action
  cancelFilter() {
    this.postStream.cancelFilter();
    this.postStream.refresh();
    this._close();
  }

  @action
  handleFilterPosts() {
    this.filterPosts(this.user);
    this._close();
  }

  @action
  deleteUser() {
    this.user.delete();
    this._close();
  }

  @action
  checkEmail(user) {
    user.checkEmail();
  }

  @onEvent("didInsertElement")
  _inserted() {
    this.appEvents.on("dom:clean", this, this.cleanUp);
  }

  @onEvent("didDestroyElement")
  _destroyed() {
    this.appEvents.off("dom:clean", this, this.cleanUp);
  }

  async _showCallback(username) {
    this.setProperties({ visible: true, loading: true });

    const args = {
      forCard: true,
      include_post_count_for: this.get("topic.id"),
    };

    try {
      const user = await User.findByUsername(username, args);

      if (user.topic_post_count) {
        this.set(
          "topicPostCount",
          user.topic_post_count[args.include_post_count_for]
        );
      }
      this.setProperties({ user });
      this.user.statusManager.trackStatus();

      return user;
    } catch {
      this._close();
    } finally {
      this.set("loading", null);
    }
  }

  _close() {
    this.user?.statusManager.stopTrackingStatus();

    this.setProperties({
      user: null,
      topicPostCount: null,
    });

    super._close(...arguments);
  }

  <template>
    {{#if this.visible}}
      <PluginOutlet
        @name="before-user-card-content"
        @outletArgs={{lazyHash user=this.user}}
      />
      <div class="card-content">
        {{#if this.loading}}
          <div class="card-row first-row">
            <div class="user-card-avatar">
              <div
                class="card-avatar-placeholder animated-placeholder placeholder-animation"
              ></div>
            </div>
          </div>

          <div class="card-row second-row">
            <div class="animated-placeholder placeholder-animation"></div>
          </div>
          <div class="card-row">
            <div class="animated-placeholder placeholder-animation"></div>
          </div>
          <div class="card-row">
            <div class="animated-placeholder placeholder-animation"></div>
          </div>
          <div class="card-row">
            <div class="animated-placeholder placeholder-animation"></div>
          </div>
        {{else}}
          <div class="card-row first-row">
            <PluginOutlet
              @name="user-card-main-info"
              @outletArgs={{lazyHash
                user=this.user
                post=this.post
                contentHidden=this.contentHidden
                handleShowUser=this.handleShowUser
              }}
            >
              <div aria-hidden="true" class="user-card-avatar">
                {{#if this.contentHidden}}
                  <span class="card-huge-avatar">{{dBoundAvatar
                      this.user
                      "huge"
                    }}</span>
                {{else}}
                  <a
                    class="card-huge-avatar"
                    href={{this.avatarUrl}}
                    tabindex="-1"
                  >
                    {{dBoundAvatar this.user "huge"}}
                    {{#if this.isOwnCard}}
                      <span class="own-avatar-pencil">
                        <span class="own-avatar-pencil--icon">
                          {{dIcon "pencil"}}
                        </span>
                      </span>
                    {{/if}}
                  </a>
                {{/if}}

                <DUserAvatarFlair @user={{this.user}} />

                <div>
                  <PluginOutlet
                    @connectorTagName="div"
                    @name="user-card-avatar-flair"
                    @outletArgs={{lazyHash user=this.user}}
                  />
                </div>
              </div>
              <div class="names">
                <div
                  class="names__primary
                    {{this.staff}}
                    {{this.newUser}}
                    {{if this.nameFirst 'full-name' 'username'}}"
                >
                  {{#if this.contentHidden}}
                    <span class="name-username-wrapper">
                      {{if
                        this.nameFirst
                        this.user.name
                        (formatUsername this.user.username)
                      }}
                    </span>
                  {{else}}
                    <a
                      aria-label={{i18n
                        "user.profile_link"
                        username=this.user.username
                      }}
                      class="user-profile-link"
                      href={{this.user.path}}
                      {{on "click" this.handleShowUser}}
                    >
                      <span class="name-username-wrapper">
                        {{if
                          this.nameFirst
                          this.user.name
                          (formatUsername this.user.username)
                        }}
                      </span>
                      {{userStatus this.user currentUser=this.currentUser}}
                    </a>
                  {{/if}}
                </div>
                <PluginOutlet
                  @connectorTagName="div"
                  @name="user-card-after-username"
                  @outletArgs={{lazyHash
                    user=this.user
                    showUser=this.handleShowUser
                  }}
                />
                {{#if this.nameFirst}}
                  <div
                    class="names__secondary username"
                  >{{this.user.username}}</div>
                {{else}}
                  {{#if this.user.name}}
                    <div
                      class="names__secondary full-name"
                    >{{this.user.name}}</div>
                  {{/if}}
                {{/if}}
                {{#if this.user.title}}
                  <div class="names__secondary">{{this.user.title}}</div>
                {{/if}}
                {{#if this.user.staged}}
                  <div class="names__secondary staged">{{i18n
                      "user.staged"
                    }}</div>
                {{/if}}
                {{#if this.hasStatus}}
                  <div class="user-status">
                    {{trustHTML this.userStatusEmoji}}
                    <span class="user-status__description">
                      {{this.user.status.description}}
                    </span>
                    {{dFormatDate this.user.status.ends_at format="tiny"}}
                  </div>
                {{/if}}
                <div>
                  <PluginOutlet
                    @connectorTagName="div"
                    @name="user-card-post-names"
                    @outletArgs={{lazyHash user=this.user}}
                  />
                </div>
              </div>
            </PluginOutlet>
            <ul class="usercard-controls">
              {{#if this.user.can_send_private_message_to_user}}
                <li class="compose-pm">
                  <DButton
                    class="btn-primary"
                    @action={{fn this.composePM this.user this.post}}
                    @icon="envelope"
                    @label="user.private_message"
                  />
                </li>
              {{/if}}
              <PluginOutlet
                @connectorTagName="li"
                @name="user-card-below-message-button"
                @outletArgs={{lazyHash user=this.user close=this.close}}
              />
              {{#if this.showFilter}}
                <li>
                  <DButton
                    class="btn-default"
                    @action={{fn this.handleFilterPosts this.user}}
                    @icon="filter"
                    @translatedLabel={{this.filterPostsLabel}}
                  />
                </li>
              {{/if}}
              {{#if this.hasUserFilters}}
                <li>
                  <DButton
                    @action={{this.cancelFilter}}
                    @icon="xmark"
                    @label="topic.filters.cancel"
                  />
                </li>
              {{/if}}
              {{#if this.showDelete}}
                <li>
                  <DButton
                    class="btn-danger"
                    @action={{fn this.deleteUser this.user}}
                    @icon="triangle-exclamation"
                    @label="admin.user.delete"
                  />
                </li>
              {{/if}}
              <PluginOutlet
                @connectorTagName="li"
                @name="user-card-additional-buttons"
                @outletArgs={{lazyHash user=this.user close=this.close}}
              />
            </ul>
            <PluginOutlet
              @connectorTagName="div"
              @name="user-card-additional-controls"
              @outletArgs={{lazyHash
                user=this.user
                close=this.close
                post=this.post
              }}
            />
          </div>

          {{#if this.user.profile_hidden}}
            <div class="card-row second-row">
              <div class="profile-hidden">
                <span role="alert">{{i18n "user.profile_hidden"}}</span>
              </div>
            </div>
          {{else if this.user.inactive}}
            <div class="card-row second-row">
              <div class="inactive-user">
                <span role="alert">{{i18n "user.inactive_user"}}</span>
              </div>
            </div>
          {{/if}}

          {{#if this.isRestrictedOrHasBio}}
            <div class="card-row second-row">
              {{#if this.user.suspend_reason}}
                <div class="suspended">
                  <div class="suspension-date">
                    {{dIcon "ban"}}
                    {{#if this.user.suspendedForever}}
                      {{i18n "user.suspended_permanently"}}
                    {{else}}
                      {{i18n
                        "user.suspended_notice"
                        date=this.user.suspendedTillDate
                      }}
                    {{/if}}
                  </div>
                  <div class="suspension-reason">
                    <span class="suspension-reason-title">{{i18n
                        "user.suspended_reason"
                      }}</span>
                    <span class="suspension-reason-description">{{trustHTML
                        this.user.suspend_reason
                      }}</span>
                  </div>
                </div>
              {{/if}}
              {{#if this.user.silence_reason}}
                <div class="silenced">
                  <div class="silence-date">
                    {{dIcon "microphone-slash"}}
                    {{#if this.user.silencedForever}}
                      {{i18n "user.silenced_permanently"}}
                    {{else}}
                      {{i18n
                        "user.silenced_notice"
                        date=this.user.silencedTillDate
                      }}
                    {{/if}}
                  </div>
                  <div class="silence-reason">
                    <span class="silence-reason-title">{{i18n
                        "user.silenced_reason"
                      }}</span>
                    <span class="silence-reason-description">{{trustHTML
                        this.user.silence_reason
                      }}</span>
                  </div>
                </div>
              {{/if}}
              {{#unless this.isRestricted}}
                <div class="bio">
                  <DHtmlWithLinks>
                    {{trustHTML this.user.bio_excerpt}}
                  </DHtmlWithLinks>
                </div>
              {{/unless}}
            </div>
          {{/if}}

          {{#if this.showFeaturedTopic}}
            <div class="card-row">
              <div class="featured-topic">
                <span class="desc">{{i18n "user.featured_topic"}}</span>
                <LinkTo
                  @models={{array
                    this.user.featured_topic.slug
                    this.user.featured_topic.id
                  }}
                  @route="topic"
                >{{dReplaceEmoji
                    (trustHTML this.user.featured_topic.fancy_title)
                  }}</LinkTo>
              </div>
            </div>
          {{/if}}

          {{#if this.hasLocaleOrWebsite}}
            <div class="card-row">
              <div class="location-and-website">
                {{#if this.user.website_name}}
                  <span class="website-name">
                    {{dIcon "globe"}}
                    {{#if this.linkWebsite}}
                      {{! eslint-disable ember/template-link-rel-noopener }}
                      <a
                        href={{this.user.website}}
                        rel="noopener {{unless
                          this.removeNoFollow
                          'nofollow ugc'
                        }}"
                        target="_blank"
                      >{{this.user.website_name}}</a>
                      {{! eslint-enable ember/template-link-rel-noopener }}
                    {{else}}
                      <span
                        title={{this.user.website}}
                      >{{this.user.website_name}}</span>
                    {{/if}}
                  </span>
                {{/if}}
                {{#if this.user.location}}
                  <span class="location">
                    {{dIcon "location-dot"}}
                    <span>{{this.user.location}}</span>
                  </span>
                {{/if}}
                {{#if this.showUserLocalTime}}
                  <span class="local-time" title={{i18n "local_time"}}>
                    {{dIcon "far-clock"}}
                    <span>{{this.formattedUserLocalTime}}</span>
                  </span>
                {{/if}}
                <span>
                  <PluginOutlet
                    @connectorTagName="div"
                    @name="user-card-location-and-website"
                    @outletArgs={{lazyHash user=this.user}}
                  />
                </span>
              </div>
            </div>
          {{/if}}

          <div class="card-row metadata-row">
            {{#unless this.contentHidden}}
              <div class="metadata">
                {{#if this.user.last_posted_at}}
                  <div class="metadata__last-posted">
                    <span class="desc">{{i18n "last_post"}}</span>
                    {{dFormatDate
                      this.user.last_posted_at
                      leaveAgo="true"
                    }}</div>
                {{/if}}
                <div class="metadata__user-created">
                  <span class="desc">{{i18n "joined"}}</span>
                  {{dFormatDate this.user.created_at leaveAgo="true"}}</div>
                {{#if this.user.time_read}}
                  <div
                    class="metadata__time-read"
                    title={{this.timeReadTooltip}}
                  >
                    <span class="desc">{{i18n "time_read"}}</span>
                    {{dFormatDuration this.user.time_read}}
                    {{#if this.showRecentTimeRead}}
                      <span>
                        ({{i18n
                          "time_read_recently"
                          time_read=this.recentTimeRead
                        }})
                      </span>
                    {{/if}}
                  </div>
                {{/if}}
                {{#if this.showCheckEmail}}
                  <div class="metadata__email">
                    {{dIcon "envelope" title="user.email.title"}}
                    {{#if this.user.email}}
                      {{this.user.email}}
                    {{else}}
                      <DButton
                        class="btn-primary"
                        @action={{fn this.checkEmail this.user}}
                        @icon="envelope"
                        @label="admin.users.check_email.text"
                      />
                    {{/if}}
                  </div>
                {{/if}}
                <PluginOutlet
                  @connectorTagName="div"
                  @name="user-card-metadata"
                  @outletArgs={{lazyHash user=this.user}}
                />
              </div>
            {{/unless}}
            <PluginOutlet
              @connectorTagName="div"
              @name="user-card-after-metadata"
              @outletArgs={{lazyHash user=this.user}}
            />
          </div>

          {{#if this.publicUserFields}}
            <div class="card-row">
              <div class="public-user-fields">
                {{#each this.publicUserFields as |uf|}}
                  {{#if uf.value}}
                    <div
                      class="public-user-field public-user-field__{{uf.field.dasherized_name}}"
                    >
                      <span class="user-field-name">{{uf.field.name}}:</span>
                      <span class="user-field-value">
                        {{#each uf.value as |v|}}
                          {{! some values are arrays }}
                          <span class="user-field-value-list-item">
                            {{#if uf.field.searchable}}
                              <LinkTo
                                @query={{hash name=v}}
                                @route="users"
                                {{on "click" (fn this.refreshRoute v)}}
                              >{{v}}</LinkTo>
                            {{else}}
                              {{v}}
                            {{/if}}
                          </span>
                        {{else}}
                          {{uf.value}}
                        {{/each}}
                      </span>
                    </div>
                  {{/if}}
                {{/each}}
              </div>
            </div>
          {{/if}}

          <PluginOutlet
            @connectorTagName="div"
            @name="user-card-before-badges"
            @outletArgs={{lazyHash user=this.user}}
          />

          {{#if this.showBadges}}
            <div class="card-row">
              <PluginOutlet
                @name="user-card-badges"
                @outletArgs={{lazyHash user=this.user post=this.post}}
              >
                {{#if this.user.featured_user_badges}}
                  <div class="badge-section">
                    {{#each this.user.featured_user_badges as |ub|}}
                      <UserBadge @badge={{ub.badge}} @user={{this.user}} />
                    {{/each}}
                    {{#if this.showMoreBadges}}
                      <span class="more-user-badges">
                        <LinkTo @model={{this.user}} @route="user.badges">
                          {{i18n
                            "badges.more_badges"
                            count=this.moreBadgesCount
                          }}
                        </LinkTo>
                      </span>
                    {{/if}}
                  </div>
                {{/if}}
              </PluginOutlet>
            </div>
          {{/if}}
        {{/if}}
      </div>
    {{/if}}
  </template>
}
