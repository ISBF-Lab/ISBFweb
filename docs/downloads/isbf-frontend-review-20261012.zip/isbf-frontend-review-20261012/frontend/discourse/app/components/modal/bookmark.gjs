import Component from "@glimmer/component";
import { tracked } from "@glimmer/tracking";
import { Input } from "@ember/component";
import { fn } from "@ember/helper";
import { action, computed } from "@ember/object";
import didInsert from "@ember/render-modifiers/modifiers/did-insert";
import { service } from "@ember/service";
import { trustHTML } from "@ember/template";
import { isEmpty } from "@ember/utils";
import ItsATrap from "@discourse/itsatrap";
import { Promise } from "rsvp";
import PluginOutlet from "discourse/components/plugin-outlet";
import lazyHash from "discourse/helpers/lazy-hash";
import { extractError } from "discourse/lib/ajax-error";
import { formattedReminderTime } from "discourse/lib/bookmark";
import discourseLater from "discourse/lib/later";
import { sanitize } from "discourse/lib/text";
import {
  defaultTimeShortcuts,
  TIME_SHORTCUT_TYPES,
} from "discourse/lib/time-shortcut";
import { now, parseCustomDatetime, startOfDay } from "discourse/lib/time-utils";
import { AUTO_DELETE_PREFERENCES } from "discourse/models/bookmark";
import ComboBox from "discourse/select-kit/components/combo-box";
import DButton from "discourse/ui-kit/d-button";
import DModal, {
  CLOSE_INITIATED_BY_CLICK_OUTSIDE,
} from "discourse/ui-kit/d-modal";
import DModalCancel from "discourse/ui-kit/d-modal-cancel";
import DTimeShortcutPicker from "discourse/ui-kit/d-time-shortcut-picker";
import dBasePath from "discourse/ui-kit/helpers/d-base-path";
import dIcon from "discourse/ui-kit/helpers/d-icon";
import { i18n } from "discourse-i18n";

const BOOKMARK_BINDINGS = {
  enter: { handler: "saveAndClose" },
  "d d": { handler: "delete" },
};

export default class BookmarkModal extends Component {
  @service dialog;
  @service currentUser;
  @service capabilities;
  @service bookmarkApi;
  @service site;
  @service keyboardShortcuts;

  @tracked postDetectedLocalDate = null;
  @tracked postDetectedLocalTime = null;
  @tracked postDetectedLocalTimezone = null;
  @tracked prefilledDatetime = null;
  @tracked flash = null;

  @tracked _closeWithoutSaving = false;
  @tracked _savingBookmarkManually = false;
  @tracked _saving = false;
  @tracked _deleting = false;

  _itsatrap = new ItsATrap();

  willDestroy() {
    super.willDestroy(...arguments);
    this._itsatrap?.destroy();
    this._itsatrap = null;
    this.keyboardShortcuts.unpause();
  }

  @computed("userTimezone")
  get userHasTimezoneSet() {
    return !isEmpty(this.userTimezone);
  }

  @computed("bookmark.id")
  get showDelete() {
    return !isEmpty(this.bookmark?.id);
  }

  @computed("bookmark.id")
  get editingExistingBookmark() {
    return !isEmpty(this.bookmark?.id);
  }

  @computed("bookmark.id", "bookmark.reminderAt")
  get existingBookmarkHasReminder() {
    return this.bookmark?.id && this.bookmark?.reminderAt;
  }

  get userTimezone() {
    return this.currentUser.user_option.timezone;
  }

  get bookmark() {
    return this.args.model.bookmark;
  }

  get modalTitle() {
    return i18n(this.bookmark.id ? "bookmarks.edit" : "bookmarks.create");
  }

  get autoDeletePreferences() {
    return Object.keys(AUTO_DELETE_PREFERENCES).map((key) => {
      return {
        id: AUTO_DELETE_PREFERENCES[key],
        name: i18n(`bookmarks.auto_delete_preference.${key.toLowerCase()}`),
      };
    });
  }

  get showExistingReminderAt() {
    return (
      this.bookmark.reminderAt &&
      Date.parse(this.bookmark.reminderAt) > new Date().getTime()
    );
  }

  get existingReminderAtFormatted() {
    return formattedReminderTime(this.bookmark.reminderAt, this.userTimezone);
  }

  get timeOptions() {
    const options = defaultTimeShortcuts(this.userTimezone);

    if (this.showPostLocalDate) {
      options.push({
        icon: "globe-americas",
        id: TIME_SHORTCUT_TYPES.POST_LOCAL_DATE,
        label: "time_shortcut.post_local_date",
        time: this.#parsedPostLocalDateTime(),
        timeFormatKey: "dates.long_no_year",
        hidden: false,
      });
    }

    return options;
  }

  get showPostLocalDate() {
    if (!this.postDetectedLocalTime || !this.postDetectedLocalDate) {
      return false;
    }

    if (this.#parsedPostLocalDateTime() < now(this.userTimezone)) {
      return false;
    }

    return true;
  }

  get hiddenTimeShortcutOptions() {
    if (this.editingExistingBookmark && !this.existingBookmarkHasReminder) {
      return [TIME_SHORTCUT_TYPES.NONE];
    }

    return [];
  }

  get customTimeShortcutLabels() {
    const labels = {};
    if (this.existingBookmarkHasReminder) {
      labels[TIME_SHORTCUT_TYPES.NONE] =
        "bookmarks.remove_reminder_keep_bookmark";
    }
    return labels;
  }

  @action
  didInsert() {
    discourseLater(() => {
      if (this.capabilities.isMobileDevice) {
        document.getElementById("bookmark-name").blur();
      }
    });

    if (!this.args.model.bookmark.id) {
      document.getElementById("tap_tile_none").classList.add("active");
    }

    this.#bindKeyboardShortcuts();
    this.#initializeExistingBookmarkData();
    this.#loadPostLocalDates();
  }

  @action
  saveAndClose() {
    this.flash = null;
    if (this._saving || this._deleting) {
      return;
    }

    this._saving = true;
    this._savingBookmarkManually = true;
    return this.#saveBookmark()
      .then(() => this.args.closeModal())
      .catch((error) => this.#handleSaveError(error))
      .finally(() => {
        this._saving = false;
      });
  }

  @action
  onTimeSelected(type, time) {
    this.bookmark.selectedReminderType = type;
    this.bookmark.selectedDatetime = time;
    this.bookmark.reminderAt = time;

    // If the type is custom, we need to wait for the user to click save, as
    // they could still be adjusting the date and time
    if (
      ![TIME_SHORTCUT_TYPES.CUSTOM, TIME_SHORTCUT_TYPES.RELATIVE].includes(type)
    ) {
      return this.saveAndClose();
    }
  }

  @action
  closingModal(closeModalArgs) {
    // If the user clicks outside the modal we save automatically for them,
    // as long as they are not already saving manually or deleting the bookmark.
    if (
      closeModalArgs.initiatedBy === CLOSE_INITIATED_BY_CLICK_OUTSIDE &&
      !this._closeWithoutSaving &&
      !this._savingBookmarkManually
    ) {
      this.#saveBookmark()
        .catch((e) => this.#handleSaveError(e))
        .then(() => {
          this.args.closeModal(closeModalArgs);
        });
    } else {
      this.args.closeModal(closeModalArgs);
    }
  }

  @action
  closeWithoutSavingBookmark() {
    this._closeWithoutSaving = true;
    this.args.closeModal({ closeWithoutSaving: this._closeWithoutSaving });
  }

  @action
  delete() {
    if (!this.bookmark.id) {
      return;
    }

    this._deleting = true;
    const deleteAction = () => {
      this._closeWithoutSaving = true;
      this.#deleteBookmark()
        .then(() => {
          this._deleting = false;
          this.args.closeModal({
            closeWithoutSaving: this._closeWithoutSaving,
          });
        })
        .catch((error) => this.#handleSaveError(error));
    };

    if (this.existingBookmarkHasReminder) {
      this.dialog.deleteConfirm({
        message: i18n("bookmarks.confirm_delete"),
        didConfirm: () => deleteAction(),
      });
    } else {
      deleteAction();
    }
  }

  #parsedPostLocalDateTime() {
    let parsedPostLocalDate = parseCustomDatetime(
      this.postDetectedLocalDate,
      this.postDetectedLocalTime,
      this.userTimezone,
      this.postDetectedLocalTimezone
    );

    if (!this.postDetectedLocalTime) {
      return startOfDay(parsedPostLocalDate);
    }

    return parsedPostLocalDate;
  }

  #saveBookmark() {
    if (this.bookmark.selectedReminderType === TIME_SHORTCUT_TYPES.CUSTOM) {
      if (!this.bookmark.reminderAtISO) {
        return Promise.reject(i18n("bookmarks.invalid_custom_datetime"));
      }
    }

    if (this.editingExistingBookmark) {
      return this.bookmarkApi.update(this.bookmark).then(() => {
        this.args.model.afterSave?.(this.bookmark);
      });
    } else {
      return this.bookmarkApi.create(this.bookmark).then(() => {
        this.args.model.afterSave?.(this.bookmark);
      });
    }
  }

  #deleteBookmark() {
    return this.bookmarkApi.delete(this.bookmark.id).then((response) => {
      this.args.model.afterDelete?.(response, this.bookmark.id);
    });
  }

  #handleSaveError(error) {
    this._savingBookmarkManually = false;
    if (typeof error === "string") {
      this.flash = sanitize(error);
    } else {
      this.flash = sanitize(extractError(error));
    }
  }

  #bindKeyboardShortcuts() {
    this.keyboardShortcuts.pause();

    Object.keys(BOOKMARK_BINDINGS).forEach((shortcut) => {
      this._itsatrap.bind(shortcut, () => {
        const binding = BOOKMARK_BINDINGS[shortcut];
        this[binding.handler]();
        return false;
      });
    });
  }

  #initializeExistingBookmarkData() {
    if (!this.existingBookmarkHasReminder || !this.editingExistingBookmark) {
      return;
    }

    this.prefilledDatetime = this.bookmark.reminderAt;
    this.bookmark.selectedDatetime = parseCustomDatetime(
      this.prefilledDatetime,
      null,
      this.userTimezone
    );
  }

  // If we detect we are bookmarking a post which has local-date data
  // in it, we can preload that date + time into the form to use as the
  // bookmark reminder date + time.
  #loadPostLocalDates() {
    if (this.bookmark.bookmarkableType !== "Post") {
      return;
    }

    const postEl = document.querySelector(
      `[data-post-id="${this.bookmark.bookmarkableId}"]`
    );
    const localDateEl = postEl?.querySelector(".discourse-local-date");

    if (localDateEl) {
      this.postDetectedLocalDate = localDateEl.dataset.date;
      this.postDetectedLocalTime = localDateEl.dataset.time;
      this.postDetectedLocalTimezone = localDateEl.dataset.timezone;
    }
  }

  <template>
    <DModal
      class="bookmark-reminder-modal"
      data-bookmark-id={{this.bookmark.id}}
      id="bookmark-reminder-modal"
      @closeModal={{this.closingModal}}
      @flash={{this.flash}}
      @flashType="error"
      @title={{this.modalTitle}}
      {{didInsert this.didInsert}}
    >
      <:headerPrimaryAction>
        <DButton
          class="btn-transparent"
          @action={{this.saveAndClose}}
          @label="bookmarks.save"
          @title="modal.close"
        />
      </:headerPrimaryAction>

      <:body>
        <div class="control-group">
          <Input
            aria-label={{i18n "post.bookmarks.name_input_label"}}
            class="bookmark-name"
            id="bookmark-name"
            name="bookmark-name"
            placeholder={{i18n "post.bookmarks.name_placeholder"}}
            @value={{this.bookmark.name}}
          />
        </div>

        <PluginOutlet
          @name="bookmark-modal-after-name"
          @outletArgs={{lazyHash bookmark=this.bookmark}}
        />

        <div class="bookmark-options-panel">
          <label
            class="control-label"
            for="bookmark_auto_delete_preference"
          >{{i18n "bookmarks.auto_delete_preference.label"}}</label>
          <ComboBox
            class="bookmark-option-selector"
            @content={{this.autoDeletePreferences}}
            @id="bookmark-auto-delete-preference"
            @onChange={{fn (mut this.bookmark.autoDeletePreference)}}
            @value={{this.bookmark.autoDeletePreference}}
          />
        </div>

        {{#if this.showExistingReminderAt}}
          <div class="alert alert-info existing-reminder-at-alert">
            {{dIcon "far-clock"}}
            <span>{{i18n
                "bookmarks.reminders.existing_reminder"
                at_date_time=this.existingReminderAtFormatted
              }}</span>
          </div>
        {{/if}}

        <div class="control-group">
          <label class="control-label">
            {{i18n "post.bookmarks.set_reminder"}}
          </label>

          {{#if this.userHasTimezoneSet}}
            <DTimeShortcutPicker
              @_itsatrap={{this._itsatrap}}
              @customLabels={{this.customTimeShortcutLabels}}
              @hiddenOptions={{this.hiddenTimeShortcutOptions}}
              @onTimeSelected={{this.onTimeSelected}}
              @prefilledDatetime={{this.prefilledDatetime}}
              @timeShortcuts={{this.timeOptions}}
            />
          {{else}}
            <div class="alert alert-info">{{trustHTML
                (i18n "bookmarks.no_timezone" basePath=(dBasePath))
              }}</div>
          {{/if}}
        </div>
      </:body>

      <:footer>
        {{#if this.site.desktopView}}
          <DButton
            class="btn-primary"
            id="save-bookmark"
            @action={{this.saveAndClose}}
            @label="bookmarks.save"
          />
          <DModalCancel @close={{this.closeWithoutSavingBookmark}} />
        {{/if}}
        {{#if this.showDelete}}
          <DButton
            class="delete-bookmark btn-danger"
            id="delete-bookmark"
            @action={{this.delete}}
            @ariaLabel="post.bookmarks.actions.delete_bookmark.name"
            @icon="trash-can"
            @title="post.bookmarks.actions.delete_bookmark.name"
          />
        {{/if}}
      </:footer>
    </DModal>
  </template>
}
