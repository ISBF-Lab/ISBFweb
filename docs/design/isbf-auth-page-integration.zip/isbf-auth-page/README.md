# ISBF 登录与邀请码注册页面

最新生产版本 `67706a5a30d71ff0b6793e5b8f55a85c4fe3ebb5`：邀请码与登录标签居中、密码小眼睛对齐和主题菜单修复已上线。

当前版本 `f5cede9c7a624d32c951c280fb910218d441a6a4` 已发布到生产，手机手势补验通过。

这是论坛接入的增量源码包。默认两个入口「登录」「注册」；登录沿用密码、邮箱验证码、通行密钥、Google 和 GitHub；注册复用邀请码、邮件验证码、学号绑定和账号激活。

注册成功后表单消失，字符聚合成对勾，同时喷出彩带；对勾成形且表单隐藏后开始 5 秒计时，然后进入论坛首页。所有字段文字居中，粒子全屏显示并贴着表单边界。

## 文件

- `source/`：本次修改的论坛及插件文件，保留原目录结构。
- `auth-page.patch`：基于生产提交 `10004ccf5090d85f80da529aeb4ecb4f3b7b1205` 的完整补丁。
- `release.json`：发布版本及文件清单。
- `screenshots/`：实际接入页面截图。
- `docs/`：接入说明、发布及回退记录。

## 安装到相同版本

在已有学院身份插件的论坛仓库中，先备份数据库、上传文件和运行配置。确认基线版本，再执行：

```bash
git apply --check auth-page.patch
git apply auth-page.patch
```

按照现有 Discourse 部署流程重新构建前端、预编译资源并重启，管理员启用 `academy_auth_page_enabled`。该开关默认关闭，需要同时开启 `academy_roles_enabled`。本次没有数据库迁移或新依赖。

使用标准论坛构建脚本会同时编译核心与插件。若手动单独构建核心，另需运行 `bin/rake assets:precompile:build_plugins`，然后 `bin/rake assets:precompile`；确认插件清单引用的文件均进入公开资源清单。

本包是增量接入源码，完整论坛、依赖、数据库、服务器配置及认证密钥不在包内。若其他分支已有改动，请审查补丁后合并，不要直接覆盖这些文件。

## 页面开关回退

关闭 `academy_auth_page_enabled` 即可恢复原页面。保留学院权限及已有账号数据。服务器完整版本回退见发布记录。

本包包含已注册邮箱的验证码提示修复：重复注册会提示前往登录；有效验证码仍可用于正常登录。

## 最新手机手势修复

当前生产源码为 `f5cede9c7a624d32c951c280fb910218d441a6a4`。背景单指拖动不会带动页面上下滚动，
普通文字长按不会弹出选择框；表单滚动和输入框选择、粘贴保留。粒子通过指针
捕获持续跟随拖动，双指缩放仍可使用。

`touch-fix.patch` 适用于修复前的 `c0f4739d143a4efbb4e7f19dafadcd56a5302a58`；其他版本请审查后合并。
`auth-page.patch` 为基于初始接入版本的完整认证页面补丁，`source/` 包含当前源码。
之前的 `ui-fix.patch` 和报告为历史记录，不需要重复应用。
本次生产合并验收报告位于 `verification/touch-fix/`，手机截图位于
`screenshots/touch-fix/`。后续部署使用已验收镜像 `local_discourse/isbf_app:auth-touch-fix-20261010` 并核对实际
运行插件，保留当前主题和其他已部署功能；完整服务器配置及凭据未包含在包内。

## 最新居中与主题菜单修复

`center-fix.patch` 适用于 `1e444b0ba4eee6e9df8633a9e538e0f2bc6c0f7f`；其他版本请审查后合并。
`source/` 为当前认证页源码，`auth-page.patch` 为从初始接入基线生成的完整补丁。
此前的补丁与报告均为历史记录，已有完整接入时只应用本次补丁即可。
合并验证报告位于 `verification/center-fix/`，截图位于 `screenshots/center-fix/`。
后续部署使用当前已验收镜像 `local_discourse/isbf_app:auth-center-fix-20261011`，并继续核对实际运行的
完整插件与数据库主题。原生主题菜单提供浅色、深色和跟随系统三个选项。
