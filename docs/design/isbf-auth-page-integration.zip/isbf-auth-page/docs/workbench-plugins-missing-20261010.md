# 工作台商城与校友入口缺失及恢复

2026-10-10 检查 `https://isbf-one.com`。当前生产源码与部署配置均为
`adfad38f708e4d606b4ed608ad2717b350330fdf`，即当天登录页面修复版本。
用户授权后，于 2026-10-10 10:27–10:29（UTC+8）补回两个插件链接并重启
Web 服务。生产容器未重建，源码提交保持不变，数据库和 Redis 持续运行。

## 检查结果

对比实际停止容器 `isbf_app_before_auth_page_20261009` 与当前容器
`isbf_app`：原有 60 个插件，恢复前 58 个，缺少的仅为以下两项；恢复后回到
60 个。

| 功能 | 插件 | 昨日发布源码 |
| --- | --- | --- |
| 校友入口 | `isbf-alumni`，版本 `0.1.1` | `bcfa8923d704e72bc7badd746bd0b0845f7a272e` |
| 商城 | `isbf-marketplace`，版本 `0.1.0` | `5df861909f630303cf2d6a98e44a75837e0e5d38` |

两个插件的完整源码仍在 `/shared/isbf-alumni-releases/` 和
`/shared/isbf-marketplace-releases/` 的上述版本目录，均带有匹配的
`.release-commit`。原容器通过插件目录下的软链接使用这些持久源码；
恢复前的当前容器缺少两条软链接，现已按原固定版本安装器补回。

默认主题仍为 ID 4。数据库中的工作台、商城和校友组件保留，工作台组件
最后更新时间为 2026-10-09 16:59:12（UTC+8）。插件缺失使站点序列化数据
不再提供 `isbf_alumni`、`isbf_marketplace`：校友卡片因此被过滤，商城卡片
因此没有跳转链接。恢复前实际 HTTPS 请求的两个功能路由均返回 404。
恢复后未登录访问返回 302 到登录页，登录页及健康接口返回 200。

启用设置仍为 true，商城分类 ID 8 仍存在，保留 3 条未删除主题及 12 条商城
自定义字段；校友原生组仍存在，本次读到的组成员及资料字段计数均为 0。
这些是当前状态计数，不代表与昨天的数据逐条比对结果。

学习资源及官方插件仍通过原来的共享源码链接加载。其运行源码与昨日提取
源码一致；目录比较须包含隐藏文件，避免将 `.release-commit` 等漏列误判为
版本差异。

## 部署原因

登录页面增量镜像构建脚本 `deploy-work/auth-page-20261009/build-minimal.py`
从保存的旧镜像开始，而非从昨日容器的实际文件系统开始。旧容器运行期间
新增的两个插件链接未进入该镜像；复制编译资源不能补回后端插件链接。
生产完整配置的构建 hooks 中已经引用这两个插件，但此次增量构建没有执行
完整 launcher 配置，因此未补装它们。

今早的回退脚本恢复容器、代码和资源清单，没有恢复数据库。当前主题字段及
启用设置也仍保留。证据支持此次镜像遗漏链接导致功能消失，不能据此将问题
归因于数据库回退。

## 已执行的恢复

恢复镜像为 `local_discourse/isbf_app:restore-workbench-20261010`，基于
`local_discourse/isbf_app:auth-ui-fix-20261010`，只新增两条插件链接。构建定义
保存在 `deploy-work/workbench-deployment-audit-20261010/image/Dockerfile`。
不需要重新编译核心前端；两个插件没有数据库迁移和前端 JavaScript bundle。
原插件的 12 个 Ruby 文件已通过语法检查。

用户授权后，在当前生产容器执行原插件的固定版本安装器，然后仅重启
Web 服务。执行前已核对当前提交仍为上述版本、目标插件路径不存在、共享
目录的版本标记及 48 个源码文件摘要均匹配本次快照。原有学习资源和官方
插件没有改动。

```bash
docker exec isbf_app bash \
  /shared/isbf-alumni-releases/bcfa8923d704e72bc7badd746bd0b0845f7a272e/isbf-alumni/deploy/install-plugin.sh \
  bcfa8923d704e72bc7badd746bd0b0845f7a272e
docker exec isbf_app bash \
  /shared/isbf-marketplace-releases/5df861909f630303cf2d6a98e44a75837e0e5d38/isbf-marketplace/deploy/install-plugin.sh \
  5df861909f630303cf2d6a98e44a75837e0e5d38
docker exec isbf_app sv -w 45 restart /etc/service/unicorn
```

两个插件均已加载并启用，站点能力字段恢复，默认主题源码摘要、相关启用
设置、商城主题与自定义字段计数均与恢复前一致。没有回退数据库或运行
数据库迁移，今早的登录源码保持原提交。

页面验收和恢复结果分别保存在审计目录的 `production-browser-report.json`
与 `production-restoration-report.json`。

恢复镜像已于 10:45（UTC+8）标记为 `local_discourse/isbf_app:latest`，镜像 ID
为 `sha256:cba7f636b10cfcaa3f35f9e1e56a2d7b28f5697e91913298ce5387e49922cf8a`。
后续增量构建使用已验收的恢复镜像，并核对运行容器的完整状态；完整
launcher 重建继续使用原配置中的插件 hooks。

本次是在容器内恢复链接，Docker 容器的 `.Image` 仍保持创建时的原镜像 ID。
构建前要同时检查当前源码提交、实际插件目录和已验收镜像记录，尤其注意
容器创建以后安装的插件和源码更新。

若恢复失败，仅移除本次添加且仍指向预期源码的两条链接，再重启 Web 服务。
不恢复数据库，不修改商城主题、校友组、默认主题或今日登录源码。

## 后续发布校验

生成增量镜像前，同时核对实际运行容器的插件目录、链接目标、共享源码版本、
插件设置和前端能力字段；与候选镜像比较时挂载相同的只读发布源码目录。
仅核对 Git HEAD、健康接口和登录页不足以发现外部插件遗漏。

页面验收须等待商品查询成功及列表完成渲染，校友页须确认地图完成初始化。
页面容器出现或路由改变只能证明跳转，不能证明数据已加载。布尔属性在
加载结束后可能被框架移除，验收应检查实际内容和加载提示是否消失。

审计证据和提取源码保存在
`deploy-work/workbench-deployment-audit-20261010/`，包含完整插件目录对比、
源码摘要、主题字段、设置和数据计数。未导出用户资料表、SMTP 凭据或完整
运行配置；浏览器截图用于本地验收，临时只读验收凭据在脚本结束时删除。

根据用户要求记住本次问题，已在 `AI-AGENTS.md`（`AGENTS.md` 的链接目标）
加入部署必读记录、完整插件对比和页面数据加载校验要求，并重新加载该文件。

## 最新已验收镜像参考（手机触控修复）

2026-10-10 23:16:46（UTC+8）完成手机背景手势修复，当前源码为
`f5cede9c7a624d32c951c280fb910218d441a6a4`。最新已验收镜像更新为 `local_discourse/isbf_app:auth-touch-fix-20261010`，
ID `sha256:7d34fb8b0b30c85230af9ddfc20ca02df66fcceb85deded1b0c920cb507d141d`，同时标记为 `local_discourse/isbf_app:latest`。
已核对实际运行容器的全部 61 个插件、隐藏源码文件、共享发布标记和软链接；
保留后续账号关联权限及头像框管理版本。数据库主题、功能设置和已有数据未改变。
桌面及手机均确认工作台链接、商城商品加载与校友地图完成初始化。
发布及回退范围见 `docs/isbf-auth-page-production.md` 的手机触控修复记录。

## 最新已验收镜像参考（认证页居中与主题菜单）

2026-10-11 13:46:11（UTC+8）完成认证页局部修复，源码为 `67706a5a30d71ff0b6793e5b8f55a85c4fe3ebb5`。
当前已验收镜像为 `local_discourse/isbf_app:auth-center-fix-20261011`，ID `sha256:e748995d9786f7cac5d0fa1eca66e3c0fafd6765dcd50942d0a88d80ade4345a`，
同时登记为 `local_discourse/isbf_app:latest`。以实际运行文件系统核对全部
61 个插件及其隐藏文件、内部和顶层软链接、
共享版本标记，当前主题与功能设置保留。桌面及手机均确认工作台入口、商城
商品加载与校友地图完成初始化。发布范围及回退说明见认证页生产记录。
